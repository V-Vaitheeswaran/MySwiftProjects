//
//  NotePageRouter.swift
//  NoteZ
//
//  Created by Vaitheeswaran V on 24/02/23.
//

import Foundation
import UIKit

protocol NotePageWireFrameLogic{
    func goToRootPage()
}

class NotePageRouter : NotePageWireFrameLogic{
   
    weak var viewController : UIViewController!
    
    func goToRootPage() {
        viewController.navigationController?.popViewController(animated: true)
    }
    
   
}
