//
//  HomePageEntity.swift
//  AdvancedTableView
//
//  Created by Vaitheeswaran V on 31/01/23.
//

import Foundation

struct NotePageModel{
    
    struct NoteModel{
        var title : String
        var content : String
        var noteId: String?
    }
}
