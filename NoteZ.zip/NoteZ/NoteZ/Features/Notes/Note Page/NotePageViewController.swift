//
//  NotePageViewController.swift
//  NoteZ
//
//  Created by Vaitheeswaran V on 24/02/23.
//

import UIKit
import Speech

enum ModeOfAccess{
    case create, edit(title:String,content:String,id:String)
}

protocol NotePageDisplayLogic{
    func displaySuccess(message:String)
    func displayError(message:String)
}

class NotePageViewController: UIViewController {
    
    @IBOutlet weak var titleLabel: UITextField!
    
    @IBOutlet weak var contentView: UITextView!
    
    @IBOutlet weak var speechButton: UIButton!
    
    var speechStarted = false
    let audioEngine = AVAudioEngine()
    let speechReconizer : SFSpeechRecognizer? = SFSpeechRecognizer()
    
    let request = SFSpeechAudioBufferRecognitionRequest()
    var task : SFSpeechRecognitionTask!
    
    var noteId : String?
    
    var note : NotePageModel.NoteModel!

    var accessMode : ModeOfAccess = .create
    var interactor : NotePageBusinessLogic!
    var router : NotePageWireFrameLogic!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        requestPermission()
        setUp()
        
        switch accessMode {
        case .create:
            navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Save", style: .plain, target: self, action: #selector(saveTapped))
            noteId = nil
            contentView.becomeFirstResponder()
        case .edit(let title, let content,let id):
            titleLabel.text = title
            contentView.text = content
            noteId = id
            contentView.isEditable = false
            titleLabel.isUserInteractionEnabled = false
            navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Edit", style: .plain, target: self, action: #selector(editTapped))
        }
//        centerButton()
        
        tabBarController?.tabBar.isHidden = true
    }
    
    func setUp(){
        let interactor = NotePageInteractor()
        let presenter = NotePresenter()
        let viewcontroller = self
        let router = NotePageRouter()
        interactor.presenter = presenter
        presenter.viewController = viewcontroller
        viewcontroller.interactor = interactor
        viewcontroller.router = router
        router.viewController = viewcontroller
    }
    
    
    @IBAction func speechOptionClicked(_ sender: Any) {
        speechStarted = !speechStarted
        if speechStarted{
            startspeech()
            speechButton.setImage(UIImage(systemName: "mic.slash"), for: .normal)
        }
        else{
            cancelSpeech()
            speechButton.setImage(UIImage(systemName: "mic"), for: .normal)
        }
    }
    
    func requestPermission(){
        self.speechButton.isEnabled = true
        SFSpeechRecognizer.requestAuthorization{(authState) in
            DispatchQueue.main.async {
                if authState == .authorized{
                    print("Accept")
                }
                else if authState == .denied{
                    self.alertView(message: "denied")
                }
                else if authState == .notDetermined{
                    self.alertView(message: "notDetermined")
                }else if authState == .restricted {
                    self.alertView(message: "restricted")
                }
            }
        }
    }
    
    func startspeech(){
        let node = audioEngine.inputNode
        let recordingformat = node.outputFormat(forBus: 0)
        
        node.installTap(onBus: 0, bufferSize: 1024, format: recordingformat){(buffer,_) in
            self.request.append(buffer)
        }
        audioEngine.prepare()
        do{
            try audioEngine.start()
        }catch let error{
            alertView(message: "Error")
        }
        guard let myRecognization = SFSpeechRecognizer() else{
           alertView(message: "Recognization")
            return
        }
        
        
        if !myRecognization.isAvailable {
           alertView(message: "After some time")
        }
        task = speechReconizer?.recognitionTask(with: request, resultHandler: {(response , error) in
            guard let response = response else{
                if error != nil{
                    print(error.debugDescription)
                }else{
                    print(error.debugDescription)
                }
                return
            }
            let message = response.bestTranscription.formattedString
            self.contentView.text = message
        })
    }
    
    func cancelSpeech(){
        task.finish()
        task.cancel()
        task = nil
        
        
        request.endAudio()
        audioEngine.stop()
        audioEngine.inputNode.removeTap(onBus: 0)
    }
    
    func alertView(message:String){
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        self.present(alert, animated: true)
    }

   
    @objc func saveTapped(){
        let title = titleLabel.text!
        let content = contentView.text!
        let note = NotePageModel.NoteModel(title: title, content: content)
        interactor.saveInFirebase(note: note)
//        interactor.storeData(title: title, content: content)
        
    }
    
    @objc func editTapped(){
        contentView.isEditable = true
        titleLabel.isUserInteractionEnabled = true
        navigationItem.rightBarButtonItem = UIBarButtonItem(title: "Save", style: .plain, target: self, action: #selector(saveAfterEdit))
        contentView.becomeFirstResponder()

    }
    
    @objc func saveAfterEdit(){
        let title = titleLabel.text!
        let content = contentView.text!
        let note = NotePageModel.NoteModel(title: title, content: content,noteId: noteId)
        interactor.editInFirebase(note: note)

//        interactor.editData(title: title, content: content, id: id)
    }

}

extension NotePageViewController : NotePageDisplayLogic{
    func displaySuccess(message:String) {
        let alert = UIAlertController(title: "Success", message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "Ok", style: .default) { action in
            self.router.goToRootPage()
        }
        
        alert.addAction(action)
        self.present(alert, animated: true)

    }
    
    func displayError(message:String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        let action = UIAlertAction(title: "Ok", style: .default)
        
        alert.addAction(action)
        self.present(alert, animated: true)

    }
}
