//
//  NotePageInteractor.swift
//  NoteZ
//
//  Created by Vaitheeswaran V on 27/02/23.
//

import Foundation
import CoreData
import UIKit

protocol NotePageBusinessLogic{
    func saveInFirebase(note: NotePageModel.NoteModel)
    func editInFirebase(note: NotePageModel.NoteModel)
}


class NotePageInteractor : NotePageBusinessLogic{
    
    
    
    // Core Data
    var appDelegate : AppDelegate?
    var context : NSManagedObjectContext?
    
    var presenter : NotePagePresenterLogic!
    
    func saveInFirebase(note: NotePageModel.NoteModel){
        let email = UserDefaults.standard.value(forKey: "email") as! String
        DatabaseManager.shared.insertNote(with: email,note: note) { success in
            if success{
                print("data saved")
                self.presenter.getSuccess()

            }
            else{
                print("sorry")
                self.presenter.getError()

            }
        }
    }
    func editInFirebase(note: NotePageModel.NoteModel){
        let email = UserDefaults.standard.value(forKey: "email") as! String
        DatabaseManager.shared.editNote(with: email, note: note) { success in
            if success{
                print("data edited")
                self.presenter.getSuccess()
            }
            else{
                print("sorry")
                self.presenter.getError()
            }
        }
        
    }
    
}
