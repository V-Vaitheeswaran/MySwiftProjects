//
//  WallpaperPagePresenter.swift
//  AdvancedTableView
//
//  Created by Vaitheeswaran V on 31/01/23.
//

import Foundation


protocol NotePagePresenterLogic{
    func getSuccess()
    func getError()
}


class NotePresenter : NotePagePresenterLogic{
   
    var viewController : NotePageDisplayLogic!
    
    func getSuccess() {
        let message = "The Data has been Stored..."
        viewController.displaySuccess(message: message)
    }
    
    func getError() {
        let message = "Error while storing data..."
        viewController.displayError(message: message)

    }
    
    
}


