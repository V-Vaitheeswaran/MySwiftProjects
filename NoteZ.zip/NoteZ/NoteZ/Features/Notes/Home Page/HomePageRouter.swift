//
//  HomePageRouter.swift
//  NoteZ
//
//  Created by Vaitheeswaran V on 24/02/23.
//

import Foundation
import UIKit

protocol HomePageWireFrameLogic{
    func showCreateNote()
    func showEditNote(title : String,content : String,id:String)
}

class HomePageRouter : HomePageWireFrameLogic{
   
    weak var viewController : UIViewController!
    
    func showCreateNote() {
        let st = UIStoryboard(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "NotePageViewController")
        viewController.navigationController?.pushViewController(vc, animated: true)
    }
    
    func showEditNote(title: String, content: String,id:String) {
        let st = UIStoryboard(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "NotePageViewController") as!  NotePageViewController
        
        vc.accessMode = .edit(title: title, content: content,id: id)
        viewController.navigationController?.pushViewController(vc, animated: true)
    }
}
