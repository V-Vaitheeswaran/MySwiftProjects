//
//  WallpaperPageInteractor.swift
//  AdvancedTableView
//
//  Created by Vaitheeswaran V on 31/01/23.
//

import Foundation
import CoreData
import UIKit


protocol HomePageBusinessLogic{
    func fetchDataFromFirebase()
    func deleteNote(id : Int,noteId:String)
}


class HomePageInteractor : HomePageBusinessLogic{
    
    var presenter : HomePagePresenterLogic!
    
  
  
   
    
    func fetchDataFromFirebase(){
        

        let email = UserDefaults.standard.value(forKey: "email") as! String
        DatabaseManager.shared.fetchNotes(with: email) { notes in
            if notes.count == 0{
            }
            else{
                self.presenter.processData(data: notes)
            }
        }
    }
    
    func deleteNote(id:Int,noteId:String){
        DatabaseManager.shared.deleteNote(with: noteId) { result in
            if result{
                self.presenter.deleteSuccess(id: id)
            }
            else{
                self.presenter.deleteFailed()
            }
        }
    }

    
    
}
