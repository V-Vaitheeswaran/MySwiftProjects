//
//  WallpaperPagePresenter.swift
//  AdvancedTableView
//
//  Created by Vaitheeswaran V on 31/01/23.
//

import Foundation
import CoreData


protocol HomePagePresenterLogic{
    func formatData(data:[NSManagedObject])
    func processData(data : [DatabaseModel.NoteModel])
    func deleteSuccess(id : Int)
    func deleteFailed()
}


class HomePagePresenter : HomePagePresenterLogic{
    
    weak var viewController : HomePageDisplayLogic!
    var formattedData : [HomePageModel.NoteModel] = []
    
    func formatData(data: [NSManagedObject]) {
        formattedData = []
        for i in data{
            let title = i.value(forKey: "title") as! String
            let content = i.value(forKey: "content") as! String
            let id = i.value(forKey: "id") as! String
            
            
            let model = HomePageModel.NoteModel(title: title, content: content,id: id)
            formattedData.append(model)
        }
        viewController.updateData(data: formattedData)
    }
    
    func processData(data: [DatabaseModel.NoteModel]) {
        var finalData : [HomePageModel.NoteModel] = []
        for i in data{
            let note  = HomePageModel.NoteModel(title: i.title, content: i.content, id: i.id)
            finalData.append(note)
        }
        viewController.updateData(data: finalData)
        
    }
    
    func deleteSuccess(id : Int){
        viewController.noteDeleteSuccess(id : id)
    }
    
    func deleteFailed(){
        viewController.noteDeleteFailed()
    }
    
}


