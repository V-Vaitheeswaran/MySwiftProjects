//
//  ViewController.swift
//  NoteZ
//
//  Created by Vaitheeswaran V on 24/02/23.
//

import UIKit
import FirebaseAuth

protocol HomePageDisplayLogic : AnyObject{
    func updateData(data : [HomePageModel.NoteModel])
    func noteDeleteSuccess(id : Int)
    func noteDeleteFailed()

}


class HomePageViewController: UIViewController {
    
    var notes : [HomePageModel.NoteModel] = []
    var interactor : HomePageBusinessLogic!
    var router : HomePageWireFrameLogic!

    @IBOutlet weak var noteCollectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        validateAuth()
        noteCollectionView.collectionViewLayout = imageLayout()
        setUp()
        interactor.fetchDataFromFirebase()


    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        tabBarController?.tabBar.isHidden = false
        noteCollectionView.reloadData()

    }
    

    @IBAction func createButtonClicked(_ sender: Any) {
        router.showCreateNote()

    }
    func validateAuth(){
        if FirebaseAuth.Auth.auth().currentUser == nil{
            let st: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
            let vc = st.instantiateViewController(withIdentifier: "LoginNavigation") as! UINavigationController
            UIApplication.shared.windows.first?.rootViewController = vc
            UIApplication.shared.windows.first?.makeKeyAndVisible()
        }
        else{
            print("happy")
        }
    }
    func setUp(){
        let interactor = HomePageInteractor()
        let presenter = HomePagePresenter()
        let viewcontroller = self
        let router = HomePageRouter()
        interactor.presenter = presenter
        presenter.viewController = viewcontroller
        viewcontroller.interactor = interactor
        viewcontroller.router = router
        router.viewController = viewcontroller
        
    }
    
 


}


extension HomePageViewController : UICollectionViewDelegate{
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        collectionView.deselectItem(at: indexPath, animated: false)
        let title = notes[indexPath.row].title
        let content = notes[indexPath.row].content
        let id = notes[indexPath.row].id
        router.showEditNote(title: title, content: content,id: id)
    }
    
    func collectionView(_ collectionView: UICollectionView, contextMenuConfigurationForItemsAt indexPaths: [IndexPath], point: CGPoint) -> UIContextMenuConfiguration? {
        
        let download = UIAction(title:"Delete" ,
                                image: UIImage(systemName: "trash.fill"),
                                identifier: nil,
                                discoverabilityTitle: nil,
                                state: .off){ _ in
            
            let id  = self.notes[indexPaths[0].row].id
            self.interactor.deleteNote(id: indexPaths[0].row,noteId: id)
//            let cell = collectionView.cellForItem(at: indexPaths[0]) as! NotesCollectionViewCell
//            let image = cell.wallpaperImage.image
//            let id = self.collectionData?.wallpapers[indexPaths[0].row].id
//            self.saveImage(image: image!,id: id!)
//            // Then, save the image to the device gallery
//            UIImageWriteToSavedPhotosAlbum(image!, nil, nil, nil)
        }
        
        
        let config = UIContextMenuConfiguration(identifier: nil,previewProvider: nil){ _ in
            return UIMenu(title: "",
                          image: nil,
                          identifier: nil,
                          options: UIMenu.Options.displayInline,
                          children: [download]
            )
        }
        
        return config
    }
}

extension HomePageViewController : UICollectionViewDataSource{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return notes.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as! NotesCollectionViewCell
        cell.layer.cornerRadius = 10
        cell.titleLabel.text = notes[indexPath.row].title
        cell.imageView.image = UIImage(named: "1.jpg")
        return cell
    }
    
    
    
    
}

extension HomePageViewController{
    func imageLayout() -> UICollectionViewCompositionalLayout{
        
        // item
        let item = CompositionalLayout.createItem(width: .fractionalWidth(0.7), height: .fractionalHeight(1))
        item.contentInsets = NSDirectionalEdgeInsets(top: 10, leading: 20, bottom: 10, trailing: 10) // set the leading contentInset to 100

        // group
        let group = CompositionalLayout.createGroup(alignment: .horizontal, width: .fractionalWidth(1), height: .fractionalHeight(0.35), item: item, count: 2)
        group.interItemSpacing = .fixed(0)

        // section
        let section = NSCollectionLayoutSection(group: group)
        
        return UICollectionViewCompositionalLayout(section: section)
    }
}

extension HomePageViewController : HomePageDisplayLogic{
    func updateData(data: [HomePageModel.NoteModel]) {
        notes = []
        notes = data
        DispatchQueue.main.async {
            self.noteCollectionView.reloadData()
        }
    }
    
    func noteDeleteSuccess(id:Int) {
        self.notes.remove(at: id)
        DispatchQueue.main.async {
            self.noteCollectionView.reloadData()
        }
    }
    
    func noteDeleteFailed() {
        let alert = UIAlertController(title: "Failed", message: "Deletion of Note Failed", preferredStyle: .actionSheet)
        let action = UIAlertAction(title: "OK", style: .cancel)
        alert.addAction(action)
        self.present(alert, animated: true)
    }
    
}
