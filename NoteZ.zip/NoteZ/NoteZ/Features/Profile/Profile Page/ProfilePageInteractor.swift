//
//  WallpaperPageInteractor.swift
//  AdvancedTableView
//
//  Created by Vaitheeswaran V on 31/01/23.
//

import Foundation
import CoreData
import UIKit



protocol ProfilePageBusinessLogic{
}


class ProfilePageInteractor : ProfilePageBusinessLogic{

    
    var presenter : ProfilePagePresenterLogic!
  
    
   
    
    
}
