//
//  SettingsPageEntity.swift
//  AdvancedTableView
//
//  Created by Vaitheeswaran V on 31/01/23.
//

import Foundation

struct ProfilePageModel{
    
    struct NoteModel{
        var title : String
        var content : String
    }
}
