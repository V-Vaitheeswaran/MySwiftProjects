//
//  SettingsPageRouter.swift

//  NoteZ
//
//  Created by Vaitheeswaran V on 24/02/23.
//

import Foundation
import UIKit

protocol ProfilePageWireFrameLogic{
    func showCreateNote()
    func showEditNote(title : String,content : String)
}

class ProfilePageRouter : ProfilePageWireFrameLogic{
   
    weak var viewController : UIViewController!
    
    func showCreateNote() {
        let st = UIStoryboard(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "NotePageViewController")
        viewController.navigationController?.pushViewController(vc, animated: true)
    }
    
    func showEditNote(title: String, content: String) {
        let st = UIStoryboard(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "NotePageViewController")
        viewController.navigationController?.pushViewController(vc, animated: true)
    }
}
