//
//  SettingsPageViewController.swift
//  NoteZ
//
//  Created by Vaitheeswaran V on 27/02/23.
//

import UIKit
import FirebaseAuth

protocol ProfilePageDisplayLogic{
  
}


class ProfilePageViewController: UIViewController {
    @IBOutlet weak var profilePicture: UIImageView!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var emailLabel: UILabel!
    
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var logOutButton: UIButton!
    
    
    var settingsDetails = ["Settings","Rate Us","Feedback","Version"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getUserData()
        uiAlignments()

    }
    
    func uiAlignments(){
        profilePicture.layer.cornerRadius = profilePicture.frame.width/2
    }
    
    @IBAction func logOutTapped(_ sender: Any) {
        let alert = UIAlertController(title: "Log out", message: "Do you wanna log out?", preferredStyle: .actionSheet)
        
        let okAction = UIAlertAction(title: "Ok",style: .default){ alert in
            self.logOutUser()
        }
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel){ cancel in
            alert.dismiss(animated: true)
        }
        alert.addAction(okAction)
        alert.addAction(cancelAction)
        self.present(alert, animated: true)
    }
    
    func logOutUser(){
        print("logging Out")
        do{
            try FirebaseAuth.Auth.auth().signOut()
            moveToLogin()
            
        }
        catch{
            print("Failed to Log Out")
        }
        
    }
    
    func moveToLogin(){
        let st: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "LoginNavigation") as! UINavigationController
        UIApplication.shared.windows.first?.rootViewController = vc
        UIApplication.shared.windows.first?.makeKeyAndVisible()
    }
    
}

extension ProfilePageViewController : ProfilePageDisplayLogic{
  
}


extension ProfilePageViewController : UITableViewDelegate{
    
}

extension ProfilePageViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return settingsDetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.font = UIFont(name: (cell.textLabel?.font.fontName)!, size: 20)

        cell.textLabel?.text = settingsDetails[indexPath.row]
        return cell
    }
    
    
}


extension ProfilePageViewController{
    func getUserData(){
        guard let email = UserDefaults.standard.value(forKey: "email") as? String else{
            return
        }
        DispatchQueue.main.async {
            self.emailLabel.text = email
        }
        DatabaseManager.shared.getUser(with: email) { data in
            self.nameLabel.text = data.username
        }
        
        let safeEmail = DatabaseManager.safeEmailMaker(email: email)
        let fileName = safeEmail + "_profile_picture.png"
        let path = "images/" + fileName
        
        StorageManager.shared.downloadUrl(for: path, completion: { result in
            switch result{
            case .success(let url):
                self.downloadImage(url: url)
                
            case .failure(let error):
                self.profilePicture.image = UIImage(systemName: "person")
            }
        })
    }
    
    func downloadImage(url:URL){
        let urlRequest = URLRequest(url: url)
        URLSession.shared.dataTask(with: urlRequest,completionHandler: { data,_,error in
            guard let data = data, error == nil else{
                return
            }
            let image = UIImage(data: data)
            
            DispatchQueue.main.async {
                self.profilePicture.image = image
                
            }
            
        }).resume()
        
    }
}
