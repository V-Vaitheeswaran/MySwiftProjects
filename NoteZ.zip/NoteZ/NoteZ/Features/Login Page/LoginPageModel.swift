//
//  LoginPageEntity.swift
//  AdvancedTableView
//
//  Created by Vaitheeswaran V on 31/01/23.
//

import Foundation

struct LoginPageModel{
    
    struct NoteModel{
        var title : String
        var content : String
    }
}
