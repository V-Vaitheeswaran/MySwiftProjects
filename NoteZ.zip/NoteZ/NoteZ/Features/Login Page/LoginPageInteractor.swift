//
//  WallpaperPageInteractor.swift
//  AdvancedTableView
//
//  Created by Vaitheeswaran V on 31/01/23.
//

import Foundation
import CoreData
import FirebaseAuth

protocol LoginPageBusinessLogic{
    func loginUser(email:String,password:String)
}


class LoginPageInteractor : LoginPageBusinessLogic{
    var presenter : LoginPagePresenterLogic!
  
    func loginUser(email: String, password: String) {
        FirebaseAuth.Auth.auth().signIn(withEmail: email, password: password){authResult, error in
            
            guard let result = authResult, error == nil else{
                let message = "Failed to log in user with email :  \(email)"
                self.presenter.loginFailure(message: message)
                return
            }
            let user = result.user
            
            UserDefaults.standard.set(email, forKey: "email")
            
            print("Logged In User :\(user)")
            self.presenter.loginSuccess()
            
        }
    }
    
    
}
