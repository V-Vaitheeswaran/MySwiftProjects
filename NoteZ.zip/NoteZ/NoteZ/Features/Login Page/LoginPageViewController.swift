//
//  LoginPageViewController.swift
//  NoteZ
//
//  Created by Vaitheeswaran V on 24/02/23.
//

import UIKit
import FirebaseAuth


protocol LoginPageDisplayLogic{
    func changeToHomePage()
    func displayError(error:String)
}

class LoginPageViewController: UIViewController {

    @IBOutlet weak var emailField: UITextField!
    
    @IBOutlet weak var passwordField: UITextField!
    
    @IBOutlet weak var loginButton: UIButton!
    
    @IBOutlet weak var signInButton: UIButton!
    
    var interactor : LoginPageBusinessLogic!
    var router : LoginPageWireFrameLogic!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        uiAdjustments()
        setUp()
    }
    func setUp(){
            let viewController = self
            let interactor = LoginPageInteractor()
            let presenter = LoginPagePresenter()
            let router = LoginPageRouter()
            
            interactor.presenter = presenter
            presenter.viewController = viewController
            viewController.router = router
            router.viewController = viewController
            viewController.interactor = interactor
            
        }
    
    

    @IBAction func signInTapped(_ sender: Any) {
        router.goToRegisterPage()
    }
    @IBAction func loginTapped(_ sender: Any) {
        let email = emailField.text!
        let password = passwordField.text!
        let alert = UIAlertController(title:"Error!", message: "please check the following field", preferredStyle: .alert)
        let action = UIAlertAction(title: "Ok", style: .cancel)
        alert.addAction(action)
        if BasicRegex.shared.checkEmail(email: email){
            if BasicRegex.shared.checkPassword(password: password){
                interactor.loginUser(email:email,password:password)
            }
            else{
                alert.message = "please enter the password in correct format"
                self.present(alert, animated: true)
            }
        }
        
        else{
            alert.message = "please enter the email in correct format"
            self.present(alert, animated: true)
        }
        
    }

    func uiAdjustments(){
        emailField.layer.borderColor = UIColor.lightGray.cgColor
        passwordField.layer.borderColor = UIColor.lightGray.cgColor
        
        passwordField.layer.cornerRadius = 20
        emailField.layer.cornerRadius = 20
        passwordField.isSecureTextEntry = true
        
        passwordField.setLeftPaddingPoints(20)
        emailField.setLeftPaddingPoints(20)
        
        emailField.layer.borderWidth = 1.0
        passwordField.layer.borderWidth = 1.0
  


    }
    
}

extension LoginPageViewController:LoginPageDisplayLogic{
    func changeToHomePage() {
        router.goToMainPage()
    }
    
    func displayError(error: String) {
        let alert = UIAlertController(title: "Error", message: error, preferredStyle: .actionSheet)
        let okAction = UIAlertAction(title: "Ok", style: .default)
        alert.addAction(okAction)
        self.present(alert, animated: true)
    }
}
