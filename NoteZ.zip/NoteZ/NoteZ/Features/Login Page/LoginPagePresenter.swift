//
//  WallpaperPagePresenter.swift
//  AdvancedTableView
//
//  Created by Vaitheeswaran V on 31/01/23.
//



import Foundation


protocol LoginPagePresenterLogic{
    func loginSuccess()
    func loginFailure(message:String)
}


class LoginPagePresenter : LoginPagePresenterLogic{
    var viewController : LoginPageDisplayLogic!
    func loginSuccess() {
        viewController.changeToHomePage()
    }
    
    func loginFailure(message: String) {
        viewController.displayError(error: message)
    }
    
    
    
}
