//
//  RegisterPageEntity.swift
//  AdvancedTableView
//
//  Created by Vaitheeswaran V on 31/01/23.
//

import Foundation

struct RegisterPageModel{
    
    struct NoteModel{
        var title : String
        var content : String
    }
    
    struct NoteZUser{
        let username : String
        let email : String
        var profilePictureFileName : String{
            return "\(safeEmail)_profile_picture.png"
        }
        
        var safeEmail: String {
            var  safeEmail = email.replacingOccurrences(of:".", with: "-")
            safeEmail = safeEmail.replacingOccurrences(of: "@", with: "-")
            return safeEmail
        }
    }
}
