//
//  RegisterPageRouter.swift
//  NoteZ
//
//  Created by Vaitheeswaran V on 24/02/23.
//

import Foundation
import UIKit

protocol RegisterPageWireFrameLogic{
    func goToMainPage()
}

class RegisterPageRouter : RegisterPageWireFrameLogic{
    weak var viewController : UIViewController!
    func goToMainPage() {
        let st: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "TabBarController") as! UITabBarController
        UIApplication.shared.windows.first?.rootViewController = vc
        UIApplication.shared.windows.first?.makeKeyAndVisible()
    }
    
    
}
