//
//  RegisterPageViewController.swift
//  NoteZ
//
//  Created by Vaitheeswaran V on 27/02/23.
//

import UIKit
import FirebaseAuth

protocol RegisterPageDisplayLogic{
    func changeToHomePage()
    func displayError(error:String)
}

class RegisterPageViewController: UIViewController {
    
    @IBOutlet weak var profilePic: UIImageView!
    
    @IBOutlet weak var userNameText: UITextField!
    
    @IBOutlet weak var emailText: UITextField!
    
    @IBOutlet weak var passwordText: UITextField!
    
    @IBOutlet weak var confirmPasswordText: UITextField!
    
    @IBOutlet weak var registerButton: UIButton!
    
    var interactor : RegisterPageBusinessLogic!
    var router : RegisterPageWireFrameLogic!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        uiAdjustments()
        gestureConfig()
        setUp()
    }
    
    func setUp(){
        let viewController = self
        let interactor = RegisterPageInteractor()
        let presenter = RegisterPagePresenter()
        let router = RegisterPageRouter()
        
        interactor.presenter = presenter
        presenter.viewController = viewController
        viewController.router = router
        router.viewController = viewController
        viewController.interactor = interactor
        
    }
    
    func gestureConfig(){
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        profilePic.isUserInteractionEnabled = true
        profilePic.addGestureRecognizer(tapGestureRecognizer)
    }
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        let tappedImage = tapGestureRecognizer.view as! UIImageView
        print("clicked")
        presntPhotoActionSheet()
        // Your action
    }
    
    @IBAction func registerButtonTapped(_ sender: Any) {
        let email = emailText.text!
        let password = passwordText.text!
        let confirmPassword = confirmPasswordText.text!
        let name = userNameText.text!
        let profilePic = profilePic.image
        
        let alert = UIAlertController(title:"Error!", message: "please check the following field", preferredStyle: .alert)
        let action = UIAlertAction(title: "Ok", style: .cancel)
        alert.addAction(action)
        if BasicRegex.shared.checkEmail(email: email){
            if BasicRegex.shared.checkPassword(password: password){
                if password == confirmPassword{
                    if BasicRegex.shared.checkName(name: name){
                        interactor.createUser(email: email, name: name, password: password, profilePic: profilePic)
                    }
                    else{
                        alert.message = "please enter the name in correct format"
                        self.present(alert, animated: true)
                    }
                }
                
                else{
                    alert.message = "please make sure that the password and confirm password matches"
                    self.present(alert, animated: true)
                }
                
            }
            else{
                alert.message = "please enter the password in correct format"
                self.present(alert, animated: true)
            }
        }
        
        else{
            alert.message = "please enter the email in correct format"
            self.present(alert, animated: true)
        }
        
        
        
    }
    

    
    func uiAdjustments(){
        emailText.layer.borderColor = UIColor.lightGray.cgColor
        passwordText.layer.borderColor = UIColor.lightGray.cgColor
        confirmPasswordText.layer.borderColor = UIColor.lightGray.cgColor
        userNameText.layer.borderColor = UIColor.lightGray.cgColor
        
        profilePic.layer.cornerRadius = profilePic.frame.width/2
       
        
        passwordText.layer.cornerRadius = 20
        userNameText.layer.cornerRadius = 20
        emailText.layer.cornerRadius = 20
        confirmPasswordText.layer.cornerRadius = 20
        
        passwordText.isSecureTextEntry = true
        confirmPasswordText.isSecureTextEntry = true
        
        
        emailText.layer.borderWidth = 1.0
        userNameText.layer.borderWidth = 1.0
        passwordText.layer.borderWidth = 1.0
        confirmPasswordText.layer.borderWidth = 1.0
        
        passwordText.setLeftPaddingPoints(20)
        emailText.setLeftPaddingPoints(20)
        confirmPasswordText.setLeftPaddingPoints(20)
        userNameText.setLeftPaddingPoints(20)
        
        
    }
    
    
    
    func goToNextPage(){
        let st: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "TabBarController") as! UITabBarController
        UIApplication.shared.windows.first?.rootViewController = vc
        UIApplication.shared.windows.first?.makeKeyAndVisible()
    }
    
}


extension RegisterPageViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    
    func presntPhotoActionSheet(){
        let actionSheet  = UIAlertController(title: "Profile Picture", message: "How would you like to select a picture ?", preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        actionSheet.addAction(UIAlertAction(title: "Take Photo", style: .default, handler: { [weak self] _ in  self?.presentCamera()}))
        actionSheet.addAction(UIAlertAction(title: "Choose Photo", style: .default, handler: { [weak self] _ in self?.presentPhotoPicker() }))
        
        present(actionSheet,animated: true)
    }
    
    func presentCamera(){
        let vc = UIImagePickerController()
        vc.sourceType = .camera
        vc.delegate = self
        vc.allowsEditing = true
        present(vc,animated: true)
    }
    
    func presentPhotoPicker(){
        let vc = UIImagePickerController()
        vc.sourceType = .photoLibrary
        vc.delegate = self
        vc.allowsEditing = true
        present(vc,animated: true)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        print(info)
        picker.dismiss(animated: true, completion: nil)
        
        guard let selectedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage else{
            return
        }
        
        self.profilePic.image = selectedImage
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}

extension RegisterPageViewController : RegisterPageDisplayLogic{
    func changeToHomePage() {
        router.goToMainPage()
    }
    
    func displayError(error: String) {
        let alert = UIAlertController(title: "Error", message: error, preferredStyle: .actionSheet)
        let okAction = UIAlertAction(title: "Ok", style: .default)
        alert.addAction(okAction)
        self.present(alert, animated: true)
    }
    
    
}



extension RegisterPageViewController{
    
}

