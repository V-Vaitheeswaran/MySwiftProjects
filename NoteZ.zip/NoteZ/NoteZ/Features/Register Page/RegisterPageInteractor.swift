//
//  WallpaperPageInteractor.swift
//  AdvancedTableView
//
//  Created by Vaitheeswaran V on 31/01/23.
//

import Foundation
import FirebaseAuth
import CoreData

protocol RegisterPageBusinessLogic{
    func createUser(email:String,name:String,password:String,profilePic:UIImage?)
}


class RegisterPageInteractor : RegisterPageBusinessLogic{
    var presenter : RegisterPagePresenterLogic!
    
    func createUser(email: String, name: String, password: String,profilePic:UIImage?) {
       
        FirebaseAuth.Auth.auth().createUser(withEmail: email, password: password, completion:{ authResult, error in
            
            
            guard authResult != nil, error == nil else{
                let message = "Error Creating a User"
                self.presenter.creationFailure(message: message)
                return
            }
            
            let noteZUser =  RegisterPageModel.NoteZUser(username:name , email: email)
            
            DatabaseManager.shared.insertUser(with:noteZUser, completion: { success in
                if success{
                    //upload image
                    guard let image = profilePic else{
                        return
                    }
                    guard  let data = image.pngData() else{
                        return
                    }
                    let fileName = noteZUser.profilePictureFileName
                    StorageManager.shared.uploadProfilePicture(with: data, fileName: fileName, completion: {result in
                        switch result{
                        case .success(let downloadUrl):
                            UserDefaults.standard.set(downloadUrl,forKey: "profile_picture_url")
                            print(downloadUrl)
                        case .failure(let error):
                            let message = "Storage Manager error : \(error)"
                            self.presenter.creationFailure(message: message)
                        }
                    })
                }
            })
            
        })
        UserDefaults.standard.set(email, forKey: "email")
        presenter.creationSuccess()
         
    }
    
    
}
