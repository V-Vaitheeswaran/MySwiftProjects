//
//  WallpaperPagePresenter.swift
//  AdvancedTableView
//
//  Created by Vaitheeswaran V on 31/01/23.
//

import Foundation


protocol RegisterPagePresenterLogic{
    func creationSuccess()
    func creationFailure(message:String)
}


class RegisterPagePresenter : RegisterPagePresenterLogic{
    var viewController : RegisterPageDisplayLogic!
    
    func creationSuccess() {
        viewController.changeToHomePage()
    }
    
    func creationFailure(message: String) {
        viewController.displayError(error: message)
    }
    
   
  
    
    
}


