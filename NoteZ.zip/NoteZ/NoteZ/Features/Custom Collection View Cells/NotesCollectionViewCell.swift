//
//  NotesCollectionViewCell.swift
//  NoteZ
//
//  Created by Vaitheeswaran V on 24/02/23.
//

import UIKit

class NotesCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageView: UIImageView!
    

    @IBOutlet weak var titleLabel: UILabel!
    
}
