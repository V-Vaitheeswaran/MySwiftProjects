//
//  NoteModel.swift
//  NoteZ
//
//  Created by Vaitheeswaran V on 14/03/23.
//

import Foundation


struct DatabaseModel{
    
    struct NoteModel{
        var title : String
        var content : String
        var id : String
    }
    
    struct UserModel{
        let username : String
        let email : String
        var profilePictureFileName : String{
            return "\(safeEmail)_profile_picture.png"
        }
        
        var safeEmail: String {
            var  safeEmail = email.replacingOccurrences(of:".", with: "-")
            safeEmail = safeEmail.replacingOccurrences(of: "@", with: "-")
            return safeEmail
        }
    }
}
