import Foundation
import FirebaseDatabase

final class DatabaseManager{
    
    static let shared = DatabaseManager()
    
    private let database = Database.database().reference()
    
    static func safeEmailMaker(email: String) -> String{
        var  safeEmail = email.replacingOccurrences(of:".", with: "-")
        safeEmail = safeEmail.replacingOccurrences(of: "@", with: "-")
        return safeEmail
    }
}

// MARK: - Account Management
extension DatabaseManager{
    
    // MARK: - CHECK IF USER EXISTS IN FIREBASE
    
    public func userExists(with email: String, completion : @escaping ((Bool) -> Void)){
        var  safeEmail = email.replacingOccurrences(of:".", with: "-")
        safeEmail = safeEmail.replacingOccurrences(of: "@", with: "-")
        database.child(safeEmail).observeSingleEvent(of: .value, with: { snapshot in
            guard snapshot.value as? String != nil else {
                completion(false)
                return
            }
            completion(true)
        })
    }
    // MARK: - GET USER DATA FROM FIREBASE
    
    public func getUser(with email: String, completion : @escaping ((RegisterPageModel.NoteZUser) -> Void)){
        var  safeEmail = email.replacingOccurrences(of:".", with: "-")
        safeEmail = safeEmail.replacingOccurrences(of: "@", with: "-")
        database.child(safeEmail).observeSingleEvent(of: .value){ snapshot in
            guard let userData = snapshot.value as? [String: Any],
                  let userName = userData["user_name"] as? String else {
                print("No user data found")
                return
            }
            
            let user = RegisterPageModel.NoteZUser(username: userName, email: email)
            completion(user)
        }
    }
    // MARK: - INSERT USER INTO FIREBASE
    public func insertUser(with user : RegisterPageModel.NoteZUser, completion:@escaping (Bool) -> Void){
        database.child(user.safeEmail).setValue([
            "user_name" : user.username,
        ]
                                                ,withCompletionBlock: {error, _ in
            guard error == nil else{
                print("FAILED TO WRITE")
                completion(false)
                return
            }
            self.database.child("users").observeSingleEvent(of: .value) { snapshot in
                if var users = snapshot.value as? [[String:String]]{
                    let newUser = ["name" : user.username,
                                   "email" : user.safeEmail
                    ]
                    users.append(newUser)
                    self.database.child("users").setValue(users) { error, _ in
                        guard error == nil else{
                            completion(false)
                            return
                        }
                        completion(true)
                        
                    }
                    
                }
                
                else{
                    let newCollection : [[String:String]] = [
                        ["name" : user.username,
                         "email" : user.safeEmail
                        ]
                        
                    ]
                    self.database.child("users").setValue(newCollection) { error, _ in
                        guard error == nil else{
                            completion(false)
                            return
                        }
                        completion(true)
                        
                    }
                }
            }
        })
    }
}


// MARK: - NOTE MANAGEMENT

extension DatabaseManager{
    
    
    public func insertNote(with email : String, note : NotePageModel.NoteModel, completion:@escaping (Bool) -> Void){
        
        let email = UserDefaults.standard.value(forKey: "email") as! String
        let safeEmail = DatabaseManager.safeEmailMaker(email: email)
        //        var type : String = "expense"
        
        //        let id =  UserDefaults.standard.value(forKey: "transactionId") as! Int
        var noteId = UUID().uuidString
        database.child("notes").child(safeEmail).child(noteId).setValue([
            "title": note.title ,
            "content": note.content ,
        ])
        
        
    }
    
    public func editNote(with email : String, note : NotePageModel.NoteModel, completion:@escaping (Bool) -> Void){
        
        let email = UserDefaults.standard.value(forKey: "email") as! String
        let safeEmail = DatabaseManager.safeEmailMaker(email: email)
        //        var type : String = "expense"
        
        //        let id =  UserDefaults.standard.value(forKey: "transactionId") as! Int
        var noteId = note.noteId!
        database.child("notes").child(safeEmail).child(noteId).setValue([
            "title": note.title ,
            "content": note.content ,
        ])
        
        
    }
    public func deleteNote(with noteId: String, completion:@escaping (Bool) -> Void){
        
        let notesRef = Database.database().reference().child("notes")
           let email = UserDefaults.standard.value(forKey: "email") as! String
           let userId = DatabaseManager.safeEmailMaker(email: email)
           let noteRef = notesRef.child(userId).child(noteId)

           noteRef.removeValue { (error, _) in
               if let error = error {
                   print("Error deleting note: \(error.localizedDescription)")
                   completion(false)
               } else {
                   print("Note deleted successfully")
                   completion(true)
               }
           }
        
    }
    

    
    public func fetchNotes(with email : String, completion:@escaping ([DatabaseModel.NoteModel]) -> Void){
        var notes : [DatabaseModel.NoteModel] = []
        let transactionsRef = Database.database().reference().child("notes")
        
        let userId = DatabaseManager.safeEmailMaker(email: email)
        
        let usertransactionsRef = transactionsRef.child(userId).queryOrdered(byChild: "date")
        
        usertransactionsRef.observe(.value) { snapshot,_  in
            guard let transactionsData = snapshot.value as? [String: Any] else {
                print("No transactions found for user")
                return
            }
            
            // Loop through the transactions and print their data
            
            for (noteId, notesData) in transactionsData {
                if let note = notesData as? [String: Any],
                   
                    let title = note["title"] as? String,
                   let content = note["content"] as? String
                {
                    
                    let note = DatabaseModel.NoteModel(title: title, content: content, id: noteId)
                    notes.append(note)
                    
                }
            }
            
            completion(notes)
        }
    }
}
    
    
