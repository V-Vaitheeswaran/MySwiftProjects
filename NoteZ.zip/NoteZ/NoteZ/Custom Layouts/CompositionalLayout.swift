//
//  CompositionalLayout.swift
//  PhotosApp
//
//  Created by Vaitheeswaran V on 17/01/23.
//

import Foundation
import UIKit

enum GroupAlignmnet{
    case vertical,horizontal
}

struct CompositionalLayout{
    static func createItem(width :NSCollectionLayoutDimension, height: NSCollectionLayoutDimension ) -> NSCollectionLayoutItem{
        let item = NSCollectionLayoutItem(layoutSize: NSCollectionLayoutSize(widthDimension: width, heightDimension: height))
        item.contentInsets = NSDirectionalEdgeInsets(top: 1, leading: 1, bottom: 1, trailing: 1)

        return item
    }
    
    static func createGroup(alignment : GroupAlignmnet,width :NSCollectionLayoutDimension, height: NSCollectionLayoutDimension,items : [NSCollectionLayoutItem]) -> NSCollectionLayoutGroup{
        switch alignment {
        case .vertical:
            return NSCollectionLayoutGroup.vertical(layoutSize: NSCollectionLayoutSize(widthDimension: width, heightDimension: height), subitems: items)
        case .horizontal:
            return NSCollectionLayoutGroup.horizontal(layoutSize: NSCollectionLayoutSize(widthDimension: width, heightDimension: height), subitems: items)
        }
    }
    
    static func createGroup(alignment : GroupAlignmnet,width :NSCollectionLayoutDimension, height: NSCollectionLayoutDimension,item : NSCollectionLayoutItem,count:Int) -> NSCollectionLayoutGroup{
        switch alignment {
        case .vertical:
            return  NSCollectionLayoutGroup.vertical(layoutSize: NSCollectionLayoutSize(widthDimension: width, heightDimension:height), subitem: item, count: count)
        case .horizontal:
            return NSCollectionLayoutGroup.horizontal(layoutSize: NSCollectionLayoutSize(widthDimension: width, heightDimension:height), subitem: item, count: count)
        }
    }
}
