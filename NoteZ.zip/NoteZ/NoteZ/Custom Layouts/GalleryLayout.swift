//
//  GalleryLayout.swift
//  PhotosApp
//
//  Created by Vaitheeswaran V on 17/01/23.
//

//import Foundation
//import UIKit
//
//protocol GalleryLayoutDelegate{
//    func collectionView(collectionView : UICollectionView, heightForItemAtIndexPath indexPath : IndexPath) -> CGFloat
//}
//
//class GalleryLayout : UICollectionViewLayout {
//    
//    var delegate : GalleryLayoutDelegate!
//    var numberOfColumns = 1
//    
//    private var cache = [UICollectionViewLayoutAttributes]()
//    private var contentHeight : CGFloat = 0
//    private var width : CGFloat {
//        get {
//            return CGRectGetWidth(collectionView!.bounds)
//        }
//    }
//    
//    override func collectionViewContentSize() -> CGSize{
//        return CGSize(width: width, height: contentHeight)
//    }
//}
