//
//  NoteZWidgetBundle.swift
//  NoteZWidget
//
//  Created by Vaitheeswaran V on 28/03/23.
//

import WidgetKit
import SwiftUI

@main
struct NoteZWidgetBundle: WidgetBundle {
    var body: some Widget {
        NoteZWidget()
        NoteZWidgetLiveActivity()
    }
}
