//
//  NoteZWidget.swift
//  NoteZWidget
//
//  Created by Vaitheeswaran V on 28/03/23.
//

import WidgetKit
import SwiftUI
import Intents

struct Provider: IntentTimelineProvider {
    func placeholder(in context: Context) -> SimpleEntry {
        SimpleEntry(date: Date(),configuration: ConfigurationIntent())
    }
    
    func getSnapshot(for configuration: ConfigurationIntent, in context: Context, completion: @escaping (SimpleEntry) -> ()) {
        let entry = SimpleEntry(date: Date(), configuration: configuration)
        completion(entry)
    }
    
    func getTimeline(for configuration: ConfigurationIntent, in context: Context, completion: @escaping (Timeline<Entry>) -> ()) {
        var entries: [SimpleEntry] = []
        
        // Generate a timeline consisting of five entries an hour apart, starting from the current date.
        let currentDate = Date()
        for hourOffset in 0 ..< 5 {
            let entryDate = Calendar.current.date(byAdding: .hour, value: hourOffset, to: currentDate)!
            let entry = SimpleEntry(date: entryDate, configuration: configuration)
            entries.append(entry)
        }
        
        let timeline = Timeline(entries: entries, policy: .atEnd)
        completion(timeline)
    }
}

struct SimpleEntry: TimelineEntry {
    let date: Date
    let configuration: ConfigurationIntent
}

struct NoteZWidgetEntryView : View {
    var entry: Provider.Entry
    var openURLHandler: () -> Void
    var createNoteHandler: () -> Void
    
    var body: some View {
        VStack{
            HStack(content: {
                Button(action: {
                    createNoteHandler()
                })
                {
                    Image(systemName: "square.and.pencil")
                        .resizable()
                        .scaledToFit()
                        .frame(width: 40, height: 40)
                }
                .padding(.leading)
                .padding(.top)
                
                //                Spacer()
            })
            .frame(maxWidth: .infinity, alignment: .leading)
            
            VStack(alignment: .leading, spacing: 10) {
                
                //            Color.purple.ignoresSafeArea()
                Text("Wanna note Something?")
            }
            .padding(.leading)
            .padding(.top)
            .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
            .onTapGesture {
                let userDefaults = UserDefaults(suiteName: "com.zoho.NoteZ.widget")
                userDefaults?.set("HomePageViewController", forKey: "ViewControllerToOpen")
                userDefaults?.synchronize()
                guard let url = URL(string: "NoteZ://") else { return }
                // Handle URL opening here
            }
        }
    }
}

struct NoteZWidget: Widget {
    let kind: String = "NoteZWidget"
    
    var body: some WidgetConfiguration {
        IntentConfiguration(kind: kind, intent: ConfigurationIntent.self, provider: Provider()) { entry in
            NoteZWidgetEntryView(entry: entry) {} createNoteHandler: {}
        }
        .configurationDisplayName("My Widget")
        .description("This is an example widget.")
    }
}

struct NoteZWidget_Previews: PreviewProvider {
    static var previews: some View {
        NoteZWidgetEntryView(entry: SimpleEntry(date: Date(), configuration: ConfigurationIntent()), openURLHandler: {},createNoteHandler: {})
            .previewContext(WidgetPreviewContext(family: .systemSmall))
    }
}
