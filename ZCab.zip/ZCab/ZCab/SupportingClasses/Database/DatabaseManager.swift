//
//  DatabaseManager.swift
//  ZCab
//
//  Created by Vaitheeswaran V on 29/06/23.
//

import Foundation
import FirebaseDatabase

final class DatabaseManager{
    
    static let shared = DatabaseManager()
    
    private let database = Database.database().reference()
    
    static func safeEmailMaker(email: String) -> String{
        var  safeEmail = email.replacingOccurrences(of:".", with: "-")
        safeEmail = safeEmail.replacingOccurrences(of: "@", with: "-")
        return safeEmail
    }
}

// MARK: - Account Management
extension DatabaseManager{
    
    // MARK: - CHECK IF USER EXISTS IN FIREBASE
    
    public func userExists(completion : @escaping ((Bool) -> Void)){
        let email = UserDefaults.standard.value(forKey: "email") as! String
        
        var  safeEmail = email.replacingOccurrences(of:".", with: "-")
        safeEmail = safeEmail.replacingOccurrences(of: "@", with: "-")
        database.child(safeEmail).observeSingleEvent(of: .value, with: { snapshot in
            guard snapshot.value as? String != nil else {
                completion(false)
                return
            }
            completion(true)
        })
    }
    // MARK: - GET USER DATA FROM FIREBASE
    
    public func getUser(completion : @escaping ((UserModel) -> Void)){
        let email = UserDefaults.standard.value(forKey: "email") as! String
        
        var  safeEmail = email.replacingOccurrences(of:".", with: "-")
        safeEmail = safeEmail.replacingOccurrences(of: "@", with: "-")
        database.child(safeEmail).observeSingleEvent(of: .value){ snapshot in
            guard let userData = snapshot.value as? [String: Any],
                  let userName = userData["user_name"] as? String else {
                print("No user data found")
                return
            }
            
            let user = UserModel(userName: userName, email: email)
            completion(user)
        }
        
    }
    
    
    // MARK: - INSERT USER INTO FIREBASE
    public func insertUser(with user : UserModel, completion:@escaping (Bool) -> Void){        database.child(user.safeEmail).setValue([
        "user_name" : user.userName,
    ]
                                                                                                                                       ,withCompletionBlock: {error, _ in
        guard error == nil else{
            print("FAILED TO WRITE")
            completion(false)
            return
        }
        self.database.child("users").observeSingleEvent(of: .value) { snapshot in
            if var users = snapshot.value as? [[String:String]]{
                let newUser = ["name" : user.userName,
                               "email" : user.safeEmail
                ]
                users.append(newUser)
                self.database.child("users").setValue(users) { error, _ in
                    guard error == nil else{
                        completion(false)
                        return
                    }
                    completion(true)
                    
                }
                
            }
            
            else{
                let newCollection : [[String:String]] = [
                    ["name" : user.userName,
                     "email" : user.safeEmail
                    ]
                    
                ]
                self.database.child("users").setValue(newCollection) { error, _ in
                    guard error == nil else{
                        completion(false)
                        return
                    }
                    completion(true)
                    
                }
            }
        }
    })
    }
}


