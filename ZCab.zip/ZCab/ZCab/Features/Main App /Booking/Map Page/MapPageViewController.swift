//
//  ViewController.swift
//  ZCab
//
//  Created by Vaitheeswaran V on 16/06/23.
//

import UIKit
import MapKit
import CoreLocation


enum MapMode{
    case track, pin
}
class MapPageViewController: UIViewController {
    
    private var sideMenuViewController: MenuPageViewController!
    private var sideMenuWidth: CGFloat {
        if view.bounds.width / 2 >= 300{
            return view.bounds.width / 2
        }
        else{
            return 300
            
        }
    }
    var type : MapMode!
    private var sideMenuOpen = false
    
    private var currentOrientation: UIInterfaceOrientation = .portrait
    
    
    @IBOutlet weak var mapView: MKMapView!
    
    
  
    
    
    lazy var locationManager: CLLocationManager = {
        var manager = CLLocationManager()
        manager.distanceFilter = 10
        manager.desiredAccuracy = kCLLocationAccuracyBest
        return manager
    }()
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.tabBarController?.tabBar.isHidden = true
    }

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.tabBarController?.tabBar.isHidden = false
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        switch type {
        case .track:
            title = "Track Your Cab"
        case .pin:
            title = "Choose the Location"

        case .none:
            break
        }
 
        let uilgr = UILongPressGestureRecognizer(target: self, action: #selector(addAnnotationOnMap(_:)))
        uilgr.minimumPressDuration = 0.5
        mapView.addGestureRecognizer(uilgr)
    }
    
    
    
    func locationManagerSetup(){
        locationManager.delegate = self
        locationManager.requestWhenInUseAuthorization()
    }
    
    func updateLocationOnMap(to location: CLLocation, with title: String?) {
        
        let point = MKPointAnnotation()
        point.title = title
        point.coordinate = location.coordinate
        self.mapView.removeAnnotations(self.mapView.annotations)
        self.mapView.addAnnotation(point)
        
        let viewRegion = MKCoordinateRegion(center: location.coordinate, latitudinalMeters: 200, longitudinalMeters: 200)
        self.mapView.setRegion(viewRegion, animated: true)
    }
    
    

    
}


extension MapPageViewController : CLLocationManagerDelegate{
    
    
    func locationManager(_ manager: CLLocationManager,
                         didChangeAuthorization status: CLAuthorizationStatus) {
        
        if status == .authorizedWhenInUse || status == .authorizedAlways {
            locationManager.startUpdatingLocation()
        }
        
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation])
    {
        
        let location = locations.last! as CLLocation
        
        let center = CLLocationCoordinate2D(latitude: location.coordinate.latitude, longitude: location.coordinate.longitude)
        let region = MKCoordinateRegion(center: center, span: MKCoordinateSpan(latitudeDelta: 0.01, longitudeDelta: 0.01))
        
        self.mapView.setRegion(region, animated: true)
    }
    
    @objc func addAnnotationOnMap(_ gestureRecognizer:UIGestureRecognizer){
        if gestureRecognizer.state == UIGestureRecognizer.State.began {
            var touchPoint = gestureRecognizer.location(in: mapView)
            var newCoordinates = mapView.convert(touchPoint, toCoordinateFrom: mapView)
            let annotation = MKPointAnnotation()
            annotation.coordinate = newCoordinates
            
            CLGeocoder().reverseGeocodeLocation(CLLocation(latitude: newCoordinates.latitude, longitude: newCoordinates.longitude), completionHandler: {(placemarks, error) -> Void in
                if error != nil {
                    print("Reverse geocoder failed with error" + error!.localizedDescription)
                    return
                }
                
                if placemarks!.count > 0 {
                    let pm = placemarks![0] as! CLPlacemark
                    
                    if let locality = pm.subLocality{
                        annotation.subtitle = locality
                    }
                    self.mapView.addAnnotation(annotation)
                    print(pm)
                }
                else {
                    annotation.title = "Unknown Place"
                    self.mapView.addAnnotation(annotation)
                    print("Problem with the data received from geocoder")
                }
                
            })
        }
    }
}

