//
//  HomePageViewController.swift
//  ZCab
//
//  Created by Vaitheeswaran V on 21/06/23.
//

import UIKit

class LocationPageViewController: UIViewController {
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    
    var otherLocations : [[String:String]] = []
    var primaryLocation : [String:String] = ["name":"Sis Safaa", "address":"GST Road, Urappakkam"]

    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    @IBAction func chooseMapClicked(_ sender: Any) {
        
        let st = UIStoryboard(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "MapPageViewController") as! MapPageViewController
        self.navigationController?.pushViewController(vc, animated: true)
    }
    

}

extension LocationPageViewController : UISearchBarDelegate{
    
}
