//
//  HomePageViewController.swift
//  ZCab
//
//  Created by Vaitheeswaran V on 27/06/23.
//

import UIKit
import CoreLocation


struct TravelModel{
    var destination : String
    var pickUpLocation : CLLocation
    var timeOfPickup : Date
    var dropLocation : CLLocation
    var isCompleted : Bool
    var driverAssigned : String
    var travelId : String
}

class HomePageViewController: UIViewController {
    
    @IBOutlet weak var tableview: UITableView!
    
    private var todaysTravel : TravelModel!
    
    private var upcomingTravels : [TravelModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    @IBAction func bookCabButtonClicked(_ sender: Any) {
        let st = UIStoryboard(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "FormPageViewController") as! FormPageViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
}


extension HomePageViewController:UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
    }
}


extension HomePageViewController : UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        if upcomingTravels.isEmpty{
            return 1
        }
        return 2
    }
    
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        if section == 0{
            return "Today"
        }
        else{
            return "Upcoming"
        }
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if section == 0{
            return 1
        }
        else{
            return upcomingTravels.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier:"HomeTableViewCell") as! HomeTableViewCell
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let height : CGFloat = tableView.bounds.height/4
        return 90
        
        
    }
    
    
}

