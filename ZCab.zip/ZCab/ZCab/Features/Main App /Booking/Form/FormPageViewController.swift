//
//  FormPageViewController.swift
//  ZCab
//
//  Created by Vaitheeswaran V on 27/06/23.
//

import UIKit

class FormPageViewController: UIViewController {
    
    
    @IBOutlet weak var datePicker: UIDatePicker!
    
    @IBOutlet weak var timePicker: UIDatePicker!
    
    @IBOutlet weak var landmark: UITextField!
    
    @IBOutlet weak var location: UITextField!
    
    @IBOutlet weak var mapButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

    }
    
    
    @IBAction func mapButtonClicked(_ sender: Any) {
        let st = UIStoryboard(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "MapPageViewController") as! MapPageViewController
        vc.type = .pin
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
