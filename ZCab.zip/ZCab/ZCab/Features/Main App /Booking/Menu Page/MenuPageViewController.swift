//
//  MenuPageViewController.swift
//  ZCab
//
//  Created by Vaitheeswaran V on 16/06/23.
//

import UIKit

class MenuPageViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }    
}
