//
//  ProfilePageViewController.swift
//  ZCab
//
//  Created by Vaitheeswaran V on 16/06/23.
//

import UIKit
import SDWebImage

class ProfilePageViewController: UIViewController {
    
    @IBOutlet weak var nameField: UILabel!
    
    @IBOutlet weak var profileImage: UIImageView!
    
    @IBOutlet weak var emailField: UILabel!
    
    @IBOutlet weak var tableView: UITableView!
    
    private var settingsDetails = ["Settings","Rate Us","Feedback","Version"]
    
    
    @IBOutlet weak var logOutButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        profileImage.layer.cornerRadius = profileImage.bounds.width/2
        DatabaseManager.shared.getUser { user in
            self.nameField.text = user.userName
            self.emailField.text = user.email
        }
        getImage()

    }
    
    func getImage() {
        let email = UserDefaults.standard.value(forKey: "email") as! String
        let safeEmail = DatabaseManager.safeEmailMaker(email: email)
        let fileName = safeEmail + "_profile_picture.png"
        let path = "images/" + fileName
        
        StorageManager.shared.downloadUrl(for: path) { result in
            switch result {
            case .success(let url):
                self.profileImage.sd_setImage(with: url,completed: nil)
            case .failure(let error):
                print(error.localizedDescription)
            }
        }
    }
}


extension ProfilePageViewController : UITableViewDelegate{
    
}


extension ProfilePageViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return settingsDetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "profileCell", for: indexPath)
        cell.textLabel?.text = settingsDetails[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    
}
