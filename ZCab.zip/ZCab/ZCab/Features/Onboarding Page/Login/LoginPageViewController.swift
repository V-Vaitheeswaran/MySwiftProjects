//
//  LoginPageViewController.swift
//  ZCab
//
//  Created by Vaitheeswaran V on 22/06/23.
//

import UIKit
import FirebaseAuth

class LoginPageViewController: UIViewController {

    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var passwordTextField: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        uiSetup()
    }
    
    
    func uiSetup(){
        emailTextField.isSecureTextEntry = false
        emailTextField.returnKeyType = .continue
        
        passwordTextField.isSecureTextEntry = true
        passwordTextField.returnKeyType = .continue
    }
    
    @IBAction func loginButtonClicked(_ sender: Any) {
        let email = emailTextField.text!
        let password = passwordTextField.text!
        let alert = UIAlertController(title:"Error!", message: "please check the following field", preferredStyle: .alert)
        let action = UIAlertAction(title: "Ok", style: .cancel)
        alert.addAction(action)
        if BasicRegex.shared.checkEmail(email: email){
            if BasicRegex.shared.checkPassword(password: password){
                loginUser(email:email,password:password)
            }
            else{
                alert.message = "please enter the password in correct format"
                self.present(alert, animated: true)
            }
        }
        
        else{
            alert.message = "please enter the email in correct format"
            self.present(alert, animated: true)
        }
        
        
    }
    
    @IBAction func signupClicked(_ sender: Any) {
        let st = UIStoryboard(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "RegisterPageViewController")
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    
    func moveToMainPage(){
        let st = UIStoryboard(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "MainTabBar")
        UIApplication.shared.windows.first?.rootViewController = vc
        UIApplication.shared.windows.first?.makeKeyAndVisible()
    }
    
    func loginUser(email:String,password:String){
        FirebaseAuth.Auth.auth().signIn(withEmail: email, password: password){authResult, error in
            
            guard let result = authResult, error == nil else{
                let message = "Failed to log in user with email :  \(email)"
                return
            }
            let user = result.user
            
            UserDefaults.standard.set(email, forKey: "email")
            DatabaseManager.shared.getUser { user in
                UserDefaults.standard.set(user.userName, forKey: "name")
            }
            
            print("Logged In User :\(user)")
            self.moveToMainPage()
            
        }
    }
}

extension LoginPageViewController: UITextFieldDelegate{
    
     func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        if textField == emailTextField{
            passwordTextField.becomeFirstResponder()
        }
        else if textField == passwordTextField{
        }
        return true
    }
}
