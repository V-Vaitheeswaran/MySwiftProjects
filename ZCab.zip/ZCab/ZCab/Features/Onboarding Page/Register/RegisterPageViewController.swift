//
//  RegisterPageViewController.swift
//  ZCab
//
//  Created by Vaitheeswaran V on 22/06/23.
//

import UIKit
import FirebaseAuth


class RegisterPageViewController: UIViewController {
    
    
    @IBOutlet weak var profileImage: UIImageView!
    
    @IBOutlet weak var nameField: UITextField!
    
    @IBOutlet weak var emailField: UITextField!
    
    @IBOutlet weak var passwordField: UITextField!
    
    @IBOutlet weak var confirmPasswordField: UITextField!
    
    @IBOutlet weak var registerButton: UIButton!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        gestureConfig()
        uiSetup()
    }
    
    func uiSetup(){
        emailField.isSecureTextEntry = false
        emailField.returnKeyType = .continue
        
        nameField.isSecureTextEntry = false
        nameField.returnKeyType = .continue
        
        passwordField.isSecureTextEntry = true
        passwordField.returnKeyType = .continue
        
        confirmPasswordField.isSecureTextEntry = true
        confirmPasswordField.returnKeyType = .done
        

    }
    func gestureConfig(){
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(imageTapped(tapGestureRecognizer:)))
        profileImage.isUserInteractionEnabled = true
        profileImage.addGestureRecognizer(tapGestureRecognizer)
        profileImage.layer.cornerRadius = profileImage.bounds.width/2
        
    }
    
    @objc func imageTapped(tapGestureRecognizer: UITapGestureRecognizer)
    {
        let tappedImage = tapGestureRecognizer.view as! UIImageView
        print("clicked")
        presntPhotoActionSheet()
        // Your action
    }

    
    @IBAction func registerButtonClicked(_ sender: Any) {
        
        let email = emailField.text!
        let password = passwordField.text!
        let confirmPassword = confirmPasswordField.text!
        let name = nameField.text!
        let profilePic = profileImage.image
        
        let alert = UIAlertController(title:"Error!", message: "please check the following field", preferredStyle: .alert)
        let action = UIAlertAction(title: "Ok", style: .cancel)
        alert.addAction(action)
        if BasicRegex.shared.checkEmail(email: email){
            if BasicRegex.shared.checkPassword(password: password){
                if password == confirmPassword{
                    if BasicRegex.shared.checkName(name: name){
                        createUser(email: email, name: name, password: password, profilePic: profilePic)
                    }
                    else{
                        alert.message = "please enter the name in correct format"
                        self.present(alert, animated: true)
                    }
                }
                
                else{
                    alert.message = "please make sure that the password and confirm password matches"
                    self.present(alert, animated: true)
                }
                
            }
            else{
                alert.message = "please enter the password in correct format"
                self.present(alert, animated: true)
            }
        }
        
        else{
            alert.message = "please enter the email in correct format"
            self.present(alert, animated: true)
        }
        
        
        
        
        
        
        func createUser(email: String, name: String, password: String, profilePic: UIImage?){
            FirebaseAuth.Auth.auth().createUser(withEmail: email, password: password, completion:{ authResult, error in
                
                
                guard authResult != nil, error == nil else{
                    let message = "Error Creating a User"
                    print(message)
                    return
                }
                
                let noteZUser =  UserModel(userName:name , email: email)
                
                DatabaseManager.shared.insertUser(with:noteZUser, completion: { success in
                    if success{
                        //upload image
                        guard let image = profilePic else{
                            return
                        }
                        guard  let data = image.pngData() else{
                            return
                        }
                        let fileName = noteZUser.profilePictureFileName
                        StorageManager.shared.uploadProfilePicture(with: data, fileName: fileName, completion: {result in
                            switch result{
                            case .success(let downloadUrl):
                                UserDefaults.standard.set(downloadUrl,forKey: "profile_picture_url")
                                print(downloadUrl)
                            case .failure(let error):
                                let message = "Storage Manager error : \(error)"
                                print(message)
                            }
                        })
                    }
                })
                
            })
            UserDefaults.standard.set(email, forKey: "email")
            self.moveToMainPage()
        }
    }
    
    func moveToMainPage(){
        let st = UIStoryboard(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "MainTabBar")
        UIApplication.shared.windows.first?.rootViewController = vc
        UIApplication.shared.windows.first?.makeKeyAndVisible()
    }
}


extension RegisterPageViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate{
    
    func presntPhotoActionSheet(){
        let actionSheet  = UIAlertController(title: "Profile Picture", message: "How would you like to select a picture ?", preferredStyle: .actionSheet)
        actionSheet.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        actionSheet.addAction(UIAlertAction(title: "Take Photo", style: .default, handler: { [weak self] _ in  self?.presentCamera()}))
        actionSheet.addAction(UIAlertAction(title: "Choose Photo", style: .default, handler: { [weak self] _ in self?.presentPhotoPicker() }))
        
        present(actionSheet,animated: true)
    }
    
    func presentCamera(){
        let vc = UIImagePickerController()
        vc.sourceType = .camera
        vc.delegate = self
        vc.allowsEditing = true
        present(vc,animated: true)
    }
    
    func presentPhotoPicker(){
        let vc = UIImagePickerController()
        vc.sourceType = .photoLibrary
        vc.delegate = self
        vc.allowsEditing = true
        present(vc,animated: true)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        print(info)
        picker.dismiss(animated: true, completion: nil)
        
        guard let selectedImage = info[UIImagePickerController.InfoKey.editedImage] as? UIImage else{
            return
        }
        
        self.profileImage.image = selectedImage
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        picker.dismiss(animated: true, completion: nil)
    }
}

extension RegisterPageViewController: UITextFieldDelegate{
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        if textField == nameField{
            emailField.becomeFirstResponder()
        }
        else if textField == emailField{
            passwordField.becomeFirstResponder()
        }
        else if textField == passwordField{
            confirmPasswordField.becomeFirstResponder()
        }
        else if textField == confirmPasswordField{
        }
        return true
    }
}

