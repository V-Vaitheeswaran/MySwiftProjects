//
//  HomeTableViewCell.swift
//  ZCab
//
//  Created by Vaitheeswaran V on 21/06/23.
//

import UIKit

class LocationTableViewCell: UITableViewCell {

    @IBOutlet weak var locationName: UILabel!
    
    @IBOutlet weak var locationAddress: UILabel!
    
}
