//
//  HomeTableViewCell.swift
//  ZCab
//
//  Created by Vaitheeswaran V on 27/06/23.
//

import UIKit

class HomeTableViewCell: UITableViewCell {

    @IBOutlet weak var location: UILabel!
    
    @IBOutlet weak var time: UILabel!
    
}
