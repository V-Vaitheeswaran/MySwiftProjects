//
//  UserMoDEL.swift
//  ZCab
//
//  Created by Vaitheeswaran V on 29/06/23.
//

import Foundation


struct UserModel{
    let userName : String
    let email : String
    var profilePictureFileName : String{
        return "\(safeEmail)_profile_picture.png"
    }
    
    var safeEmail: String {
        var  safeEmail = email.replacingOccurrences(of:".", with: "-")
        safeEmail = safeEmail.replacingOccurrences(of: "@", with: "-")
        return safeEmail
    }
}
