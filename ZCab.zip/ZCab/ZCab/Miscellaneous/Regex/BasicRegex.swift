//
//  BasicRegex.swift
//  ZCab
//
//  Created by Vaitheeswaran V on 29/06/23.
//

import Foundation


class BasicRegex{
    
    static let shared = BasicRegex()
    
    //MARK: - EMAIL VERFICATION
    func checkEmail(email: String) -> Bool{
        var validation = true
        let emailRegEx = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        
        let emailPred = NSPredicate(format:"SELF MATCHES %@", emailRegEx)
        
        if (emailPred.evaluate(with: email)) == false{
            validation = false
        }
        return validation
        
    }
    
    //MARK: - PASSWORD VERFICATION
    func checkPassword(password: String) -> Bool{
        var validation = true
        let passwordRegex = "^(?=.*[A-Z])(?=.*[!@#$&*])(?=.*[0-9])(?=.*[a-z]).{8,15}$"
        
        let passPred = NSPredicate(format:"SELF MATCHES %@", passwordRegex)
        
        if (passPred.evaluate(with: password)) == false{
            validation = false
        }
        return validation
        
    }
    //MARK: - NAME VERFICATION
    func checkName(name: String) -> Bool{
        var validation = true
        let nameRegex = "\\w{7,18}"
        let namePred = NSPredicate(format:"SELF MATCHES %@", nameRegex)
        if (namePred.evaluate(with: name)) == false{
            validation = false
        }
        return validation
        
    }

}

