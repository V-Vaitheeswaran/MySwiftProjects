//
//  DataBaseModel.swift
//  ChatAI
//
//  Created by Vaitheeswaran V on 11/05/23.
//

import Foundation


enum ChatSender {
    case ai, user
}
struct DatabaseModel{
    
    struct ConversationModel{
        var conversationId : String
        var messages : [MessageModel]
    }
    
    struct MessageModel{
        var content : String
        var sentDate: Date
        var sender : ChatSender
    }
    
    struct UserModel{
        let username : String
        let email : String
        var profilePictureFileName : String{
            return "\(safeEmail)_profile_picture.png"
        }
        
        var safeEmail: String {
            var  safeEmail = email.replacingOccurrences(of:".", with: "-")
            safeEmail = safeEmail.replacingOccurrences(of: "@", with: "-")
            return safeEmail
        }
    }
    
    struct ForumQuestionModel{
        var question : QuestionModel
        var answers : [AnswerModel]
    }
    
    struct QuestionModel{
        var id : String
        var title : String
        var description : String
        var date : Date
        var askedBy : String
        var user : String
    }
    struct AnswerModel{
        var id : String
        var answer : String
        var date : Date
        var writtenBy : String
    }
    
    
}
