//
//  DatabaseManager.swift
//  ChatAI
//
//  Created by Vaitheeswaran V on 11/05/23.
//

import Foundation
import FirebaseDatabase

final class DatabaseManager{
    
    static let shared = DatabaseManager()
    
    private let database = Database.database().reference()
    
    static func safeEmailMaker(email: String) -> String{
        var  safeEmail = email.replacingOccurrences(of:".", with: "-")
        safeEmail = safeEmail.replacingOccurrences(of: "@", with: "-")
        return safeEmail
    }
}

// MARK: - Account Management
extension DatabaseManager{
    
    // MARK: - CHECK IF USER EXISTS IN FIREBASE
    
    public func userExists(completion : @escaping ((Bool) -> Void)){
        let email = UserDefaults.standard.value(forKey: "email") as! String
        
        var  safeEmail = email.replacingOccurrences(of:".", with: "-")
        safeEmail = safeEmail.replacingOccurrences(of: "@", with: "-")
        database.child(safeEmail).observeSingleEvent(of: .value, with: { snapshot in
            guard snapshot.value as? String != nil else {
                completion(false)
                return
            }
            completion(true)
        })
    }
    // MARK: - GET USER DATA FROM FIREBASE
    
    public func getUser(completion : @escaping ((DatabaseModel.UserModel) -> Void)){
        let email = UserDefaults.standard.value(forKey: "email") as! String

        var  safeEmail = email.replacingOccurrences(of:".", with: "-")
        safeEmail = safeEmail.replacingOccurrences(of: "@", with: "-")
        database.child(safeEmail).observeSingleEvent(of: .value){ snapshot in
            guard let userData = snapshot.value as? [String: Any],
                  let userName = userData["user_name"] as? String else {
                print("No user data found")
                return
            }
            
            let user = DatabaseModel.UserModel(username: userName, email: email)
            completion(user)
        }
        
    }
    
    
    // MARK: - INSERT USER INTO FIREBASE
    public func insertUser(with user : DatabaseModel.UserModel, completion:@escaping (Bool) -> Void){        database.child(user.safeEmail).setValue([
        "user_name" : user.username,
    ]
                                            ,withCompletionBlock: {error, _ in
        guard error == nil else{
            print("FAILED TO WRITE")
            completion(false)
            return
        }
        self.database.child("users").observeSingleEvent(of: .value) { snapshot in
            if var users = snapshot.value as? [[String:String]]{
                let newUser = ["name" : user.username,
                               "email" : user.safeEmail
                ]
                users.append(newUser)
                self.database.child("users").setValue(users) { error, _ in
                    guard error == nil else{
                        completion(false)
                        return
                    }
                    completion(true)
                    
                }
                
            }
            
            else{
                let newCollection : [[String:String]] = [
                    ["name" : user.username,
                     "email" : user.safeEmail
                    ]
                    
                ]
                self.database.child("users").setValue(newCollection) { error, _ in
                    guard error == nil else{
                        completion(false)
                        return
                    }
                    completion(true)
                    
                }
            }
        }
    })
    }
}



// MARK: - CONVERSATION MANAGEMENT

extension DatabaseManager{
    
    
    public func storeConverstaion(conversation : DatabaseModel.ConversationModel, completion:@escaping (Bool) -> Void){
        
        let email = UserDefaults.standard.value(forKey: "email") as! String
        let safeEmail = DatabaseManager.safeEmailMaker(email: email)
        let conversationsRef = database.child(safeEmail).child("conversations")
        
        
        let conversationId = conversation.conversationId
        let messages = conversation.messages.map { message -> [String: Any] in
            return [
                "content": message.content,
                "sentDate": message.sentDate.timeIntervalSince1970,
                "sender": message.sender as ChatSender == .ai ? "ai" : "user"
            ]
        }
        conversationsRef.child(conversationId).setValue([
            "messages": messages
        ])
        
        
    }
    
    
    public func fetchConversations(completion:@escaping ([DatabaseModel.ConversationModel]) -> Void){
        let email = UserDefaults.standard.value(forKey: "email") as! String
        let safeEmail = DatabaseManager.safeEmailMaker(email: email)
        
        let conversationsRef = database.child(safeEmail).child("conversations")
        var convoId : String = ""
        conversationsRef.observe(.value) { snapshot in
            var conversations: [DatabaseModel.ConversationModel] = []
            
            for child in snapshot.children {
                let conversationSnapshot = child as! DataSnapshot
                convoId = conversationSnapshot.key as! String
                if let conversationData = conversationSnapshot.value as? [String: Any],
                   let messagesData = conversationData["messages"] as? [[String: Any]] {
                    
                    let messages = messagesData.map { messageData in
                        DatabaseModel.MessageModel(
                            content: messageData["content"] as! String,
                            sentDate: Date(timeIntervalSince1970: messageData["sentDate"] as! TimeInterval),
                            sender: messageData["sender"] as! String == "ai" ? .ai : .user
                        )
                    }
                    
                    let conversation = DatabaseModel.ConversationModel(
                        conversationId: convoId,
                        messages: messages
                    )
                    
                    conversations.append(conversation)
                }
            }
            
            completion(conversations)
        }
        
    }
}




//MARK: - FORUM MANAGEMENT

extension DatabaseManager{
    
    
    public func storeForumQuestion(question : DatabaseModel.ForumQuestionModel, completion:@escaping (Bool) -> Void){
        
        let email = UserDefaults.standard.value(forKey: "email") as! String
        let safeEmail = DatabaseManager.safeEmailMaker(email: email)
        let publicForum = database.child("forum").child("questions").child(question.question.id)
        let userForum = database.child("forum").child("users").child(safeEmail).child("questions").child(question.question.id)
        
        publicForum.setValue([
            "question": [
                "title": question.question.title,
                "description": question.question.description,
                "date": question.question.date.timeIntervalSince1970,
                "askedBy": question.question.askedBy,
                "user":  question.question.user
            ],
            "answers": question.answers.map { answer in
                return [
                    "id": answer.id,
                    "answer": answer.answer,
                    "date": answer.date.timeIntervalSince1970,
                    "writtenBy": answer.writtenBy
                ]
            }
        ])
        userForum.setValue([
            "question": [
                "title": question.question.title,
                "description": question.question.description,
                "date": question.question.date.timeIntervalSince1970,
                "askedBy": question.question.askedBy,
                "user":  question.question.user
            ],
            "answers": question.answers.map { answer in
                return [
                    "id": answer.id,
                    "answer": answer.answer,
                    "date": answer.date.timeIntervalSince1970,
                    "writtenBy": answer.writtenBy
                ]
            }
        ])
        
        
    }
    
    
    public func fetchAllForumQuestions(completion: @escaping ([DatabaseModel.ForumQuestionModel]?, Error?) -> Void) {
        let forumRef = database.child("forum/questions")
        
        forumRef.observeSingleEvent(of: .value) { snapshot,_ in
            guard let forumData = snapshot.value as? [String: Any] else {
                completion(nil, NSError(domain: "com.example.app", code: 0, userInfo: [NSLocalizedDescriptionKey: "No forum questions found"]))
                return
            }
            
            var forumDataModel: [DatabaseModel.ForumQuestionModel] = []
            
            for (questionID, questionData) in forumData {
                if let questionDict = questionData as? [String: Any],
                   let question = questionDict["question"] as? [String : Any],
                   let questionTitle = question["title"] ,
                   let questionDescription = question["description"] as? String,
                   let questionDate = question["date"] as? TimeInterval,
                   let questionAskedBy = question["askedBy"] as? String,let user = question["user"] as? String{
                    
                    var answersModel: [DatabaseModel.AnswerModel] = []
                    
                    if let answers = questionDict["answers"] as? [[String: Any]]{
                        for answer in answers {
                            if let answerID = answer["id"] as? String,
                               let answerText = answer["answer"] as? String,
                               let answerDate = answer["date"] as? TimeInterval,
                               let answerWrittenBy = answer["writtenBy"] as? String {
                                
                                let date = Date(timeIntervalSince1970: answerDate)
                                let answerModel = DatabaseModel.AnswerModel(id: answerID, answer: answerText, date: date, writtenBy: answerWrittenBy)
                                
                                answersModel.append(answerModel)
                            }
                        }
                    }
                    
                   
                    let date = Date(timeIntervalSince1970: questionDate)

                    let questionModel = DatabaseModel.QuestionModel(id: questionID, title: questionTitle as! String, description: questionDescription, date: date, askedBy: questionAskedBy, user: user)
                    let forumModel = DatabaseModel.ForumQuestionModel(question: questionModel, answers: answersModel)
                    
                    forumDataModel.append(forumModel)
                }
                else{
                    completion(nil, NSError(domain: "com.example.app", code: 0, userInfo: [NSLocalizedDescriptionKey: "No Question error"]))
                }
            }
            
            completion(forumDataModel, nil)
        }
    }

    public func fetchUserForumQuestions(completion: @escaping ([DatabaseModel.ForumQuestionModel]?, Error?) -> Void) {
        
        
        let email = UserDefaults.standard.value(forKey: "email") as! String
        let safeEmail = DatabaseManager.safeEmailMaker(email: email)
        let forumRef = database.child("forum/users").child(safeEmail).child("questions")
        
        forumRef.observeSingleEvent(of: .value) { snapshot,_ in
            guard let forumData = snapshot.value as? [String: Any] else {
                completion(nil, NSError(domain: "com.example.app", code: 0, userInfo: [NSLocalizedDescriptionKey: "No forum questions found"]))
                return
            }
            
            var forumDataModel: [DatabaseModel.ForumQuestionModel] = []
            
            for (questionID, questionData) in forumData {
                if let questionDict = questionData as? [String: Any],
                   let question = questionDict["question"] as? [String : Any],
                   let questionTitle = question["title"] ,
                   let questionDescription = question["description"] as? String,
                   let questionDate = question["date"] as? TimeInterval,
                   let questionAskedBy = question["askedBy"] as? String,let user = question["user"] as? String {
                    
                    var answersModel: [DatabaseModel.AnswerModel] = []
                    
                    for (answerId, answerData) in forumData {
                        if let answerDict = answerData as? [String: Any],
                           let answer = answerDict["answer"] as? String,
                           let answerDate = answerDict["date"] as? TimeInterval,
                           let answerWrittenBy = answerDict["writtenBy"] as? String {
                            
                            let date = Date(timeIntervalSince1970: answerDate)

                            var answerModel = DatabaseModel.AnswerModel(id: answerId as! String, answer: answer, date: date, writtenBy: answerWrittenBy)
                            answersModel.append(answerModel)
                        }
                    }
                    
                   
                    let date = Date(timeIntervalSince1970: questionDate)

                    let questionModel = DatabaseModel.QuestionModel(id: questionID, title: questionTitle as! String, description: questionDescription, date: date, askedBy: questionAskedBy, user: user)
                    let forumModel = DatabaseModel.ForumQuestionModel(question: questionModel, answers: answersModel)
                    
                    forumDataModel.append(forumModel)
                }
                else{
                    completion(nil, NSError(domain: "com.example.app", code: 0, userInfo: [NSLocalizedDescriptionKey: "No Question error"]))
                }
            }
            
            completion(forumDataModel, nil)
        }
    }
    
    
    public func addAnswerToQuestion(questionID: String,email: String, answer: DatabaseModel.AnswerModel, completion: @escaping (Bool, Error?) -> Void) {
        var forumRef = database.child("forum/questions").child(questionID)
        let safeEmail = DatabaseManager.safeEmailMaker(email: email)
        var userForumRef = database.child("forum/users").child(safeEmail).child("questions").child(questionID)
        forumRef.observeSingleEvent(of: .value) { snapshot,_  in
            guard let forumData = snapshot.value as? [String: Any],
                  var questionData = forumData["question"] as? [String: Any] else {
                completion(false, NSError(domain: "com.example.app", code: 0, userInfo: [NSLocalizedDescriptionKey: "Invalid question data"]))
                return
            }
           
        
            // Add the new answer to the answers array
            let answerData = [
                "answer": answer.answer,
                "date": answer.date.timeIntervalSince1970,
                "writtenBy": answer.writtenBy
            ]
            
            // Update the question data with the updated answers
            forumRef = forumRef.child("answers").child(answer.id)
            // Update the forum question in the database
            forumRef.setValue(answerData) { (error, _) in
                
            }
        }
        
        userForumRef.observeSingleEvent(of: .value) { snapshot in
            guard let forumData = snapshot.value as? [String: Any],
                  var questionData = forumData["question"] as? [String: Any] else {
                completion(false, NSError(domain: "com.example.app", code: 0, userInfo: [NSLocalizedDescriptionKey: "Invalid question data"]))
                return
            }
            var prevAnswers : [[String:Any]] = []
            if var answersDatas = forumData["answers"] as? [[String: Any]]{
                prevAnswers = answersDatas
            }
            // Add the new answer to the answers array
            let answerData = [
                "answer": answer.answer,
                "date": answer.date.timeIntervalSince1970,
                "writtenBy": answer.writtenBy
            ]
            
            // Update the question data with the updated answers
            userForumRef = userForumRef.child("answers").child(answer.id)
            // Update the forum question in the database
            userForumRef.setValue(answerData) { (error, _) in
                if let error = error {
                    completion(false, error)
                } else {
                    completion(true, nil)
                }
            }
        }
    }
    
    func fetchAllAnswers(questionID: String, completion: @escaping ([DatabaseModel.AnswerModel], Error?) -> Void){
        let forumRef = database.child("forum/questions").child(questionID).child("answers")
        
        forumRef.observeSingleEvent(of: .value) { snapshot,_  in
            guard let forumData = snapshot.value as? [String: Any] else {
                completion([],nil)
                return
            }
            var answersModel: [DatabaseModel.AnswerModel] = []
            
            for (answerId, answerData) in forumData {
                if let answerDict = answerData as? [String: Any],
                   let answer = answerDict["answer"] as? String,
                   let answerDate = answerDict["date"] as? TimeInterval,
                   let answerWrittenBy = answerDict["writtenBy"] as? String {
                    
                    let date = Date(timeIntervalSince1970: answerDate)

                    var answerModel = DatabaseModel.AnswerModel(id: answerId as! String, answer: answer, date: date, writtenBy: answerWrittenBy)
                    answersModel.append(answerModel)
                }
            }
            completion(answersModel,nil)
        }
    }

}
 
