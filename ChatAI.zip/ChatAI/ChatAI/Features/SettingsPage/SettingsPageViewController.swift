//
//  SettingsPageViewController.swift
//  ChatAI
//
//  Created by Vaitheeswaran V on 08/05/23.
//

import UIKit
import FirebaseAuth

class SettingsPageViewController: UIViewController {
    
    @IBOutlet weak var profileImage: UIImageView!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var emailLabel: UILabel!
    
    @IBOutlet weak var tableView: UITableView!
    
    @IBOutlet weak var logOutButton: UIButton!
    
    
    var data : DatabaseModel.UserModel!
    
    private var settingsDetails = ["Settings","Rate Us","Feedback","Version"]
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        updateUser()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    @IBAction func logOutClicked(_ sender: Any) {
        logOutUser()
    }
    func logOutUser(){
        print("logging Out")
        do{
            try FirebaseAuth.Auth.auth().signOut()
            UserDefaults.standard.set("", forKey: "name")
            UserDefaults.standard.set("", forKey: "email")

            moveToLogin()
            
        }
        catch{
            print("Failed to Log Out")
        }
        
    }
    
    func moveToLogin(){
        let st: UIStoryboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "LoginNavBar") as! UINavigationController
        UIApplication.shared.windows.first?.rootViewController = vc
        UIApplication.shared.windows.first?.makeKeyAndVisible()
    }

    
    func updateUser(){
        DatabaseManager.shared.getUser { model in
            self.data = model
            DispatchQueue.main.async {
                self.nameLabel.text = self.data.username
                self.emailLabel.text  = self.data.email
            }
        }
    }
    
}


extension SettingsPageViewController : UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        if indexPath.row == 0{
            guard let settingsUrl = URL(string: UIApplication.openSettingsURLString) else {
                return
            }
            if UIApplication.shared.canOpenURL(settingsUrl) {
                UIApplication.shared.open(settingsUrl, completionHandler: { (success) in
                    print("Settings opened: \(success)") // Prints true
                })
            }
        }
        else if indexPath.row == 1{
            
        }
        else{
            print("Other Button")
        }
    }
}

extension SettingsPageViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return settingsDetails.count
        
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = settingsDetails[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 60
    }
    
    
}
