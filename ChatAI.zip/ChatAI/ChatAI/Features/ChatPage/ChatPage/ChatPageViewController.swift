//
//  NewChatPageViewController.swift
//  ChatAI
//
//  Created by Vaitheeswaran V on 08/05/23.
//

import UIKit
import MessageKit
import Speech
import AVKit
import InputBarAccessoryView

enum AccessMode{
    case start
    case edit(DatabaseModel.ConversationModel)
}

struct Message: MessageType{
    var sender: SenderType
    
    var messageId: String
    
    var sentDate: Date
    
    var kind: MessageKind
    
}

struct Sender: SenderType{
    var photoURL : String
    
    var senderId: String
    
    var displayName: String
    
}



class ChatPageViewController: MessagesViewController {
    private var conversation : DatabaseModel.ConversationModel!
    private var messages = [Message]()
    var accessmode : AccessMode = .start
    
    var isStart = false
    
    let audioEngine = AVAudioEngine()
    let speechReconizer : SFSpeechRecognizer? = SFSpeechRecognizer()
    
    let request = SFSpeechAudioBufferRecognitionRequest()
    var task : SFSpeechRecognitionTask!
    
    private lazy var speechToTextButton: InputBarButtonItem = {
        let button = InputBarButtonItem()
//        button.configuration = .filled()
        button.frame.size = CGSize(width: 50, height: 50)
        button.backgroundColor = .systemBackground
        button.setImage(UIImage(systemName: "mic.fill"), for: .normal)
        button.addTarget(self, action: #selector(startSpeechToText), for: .touchUpInside)
        return button
    }()
    
    var convoId : String? = ""
    
    var selfSender = Sender(photoURL: "", senderId: "1", displayName: "You")
    
    var senderAI = Sender(photoURL: "AI.png", senderId: "2", displayName: "Victor")
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        let backButton = UIBarButtonItem(image: UIImage(systemName: "chevron.left"), style: .plain, target: self, action: #selector(backAction))
        navigationItem.leftBarButtonItem = backButton
        
        switch accessmode {
        case .start:
            messages.append(Message(sender: senderAI, messageId: "1", sentDate: Date(), kind: .text("Hi i am Victor")))
        case .edit(let conversationModel):
            convoId = conversationModel.conversationId
            fill(conversation: conversationModel)
        }
        
        
    }
    @objc func backAction() {
        if messages.count <= 1{
            print("no content to store")
        }
        else{
            storeChatInDatabase()
            
        }
        navigationController?.popViewController(animated: true)
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        messageInputBar.setStackViewItems([speechToTextButton], forStack: .left, animated: false)
        messageInputBar.setLeftStackViewWidthConstant(to: 50, animated: false)
        messageInputBar.setRightStackViewWidthConstant(to: 50, animated: false)

        messageInputBar.leftStackView.alignment = .center //HERE
        messageInputBar.rightStackView.alignment = .center //HERE
        
        messagesCollectionView.messagesDataSource = self
        messagesCollectionView.messagesLayoutDelegate = self
        messagesCollectionView.messagesDisplayDelegate = self
        messageInputBar.delegate = self
    }
    
}

//MARK: - INPUT AND TYPING CHAT

extension ChatPageViewController: InputBarAccessoryViewDelegate {
    func inputBar(_ inputBar: InputBarAccessoryView, didPressSendButtonWith text: String) {
        messages.append(Message(sender: selfSender, messageId: UUID().uuidString, sentDate: Date(), kind: .text(text)))
        DispatchQueue.main.async {
            self.messagesCollectionView.reloadData()
            self.messageInputBar.inputTextView.text = ""
            self.messageInputBar.invalidatePlugins()
        }
        APIEngine.shared.getRequest(prompt: text) { result in
            switch result {
            case .success(let answer):
                self.messages.append(Message(sender: self.senderAI, messageId: UUID().uuidString, sentDate: Date(), kind: .text(answer)))
                DispatchQueue.main.async {
                    self.messagesCollectionView.reloadData()
                    SpeechService.shared.speak(text: answer)
                }
            case .failure(let failure):
                print("error")
            }
        }
    }
    
    @objc func startSpeechToText() {
        //        self.Start.backgroundColor = .green
               isStart = !isStart
                
                if isStart{
                    startspeech()
                    speechToTextButton.setImage(UIImage(systemName: "mic.slash.fill"), for: .normal)
                }else{
                    cancelSpeech()
                    speechToTextButton.setImage(UIImage(systemName: "mic.fill"), for: .normal)
                }
        
                
                
            }
            
            func requestPermission(){
                self.speechToTextButton.isEnabled = true
                SFSpeechRecognizer.requestAuthorization{(authState) in
                    DispatchQueue.main.async {
                        if authState == .authorized{
                            print("Accept")
                        }
                        else if authState == .denied{
                            self.alertView(message: "denied")
                        }
                        else if authState == .notDetermined{
                            self.alertView(message: "notDetermined")
                        }else if authState == .restricted {
                            self.alertView(message: "restricted")
                        }
                    }
                }
            }
            
            func startspeech(){
                let node = audioEngine.inputNode
                let recordingformat = node.outputFormat(forBus: 0)
                
                node.installTap(onBus: 0, bufferSize: 1024, format: recordingformat){(buffer,_) in
                    self.request.append(buffer)
                }
                audioEngine.prepare()
                do{
                    try audioEngine.start()
                }catch let error{
                    alertView(message: "Error")
                }
                guard let myRecognization = SFSpeechRecognizer() else{
                   alertView(message: "Recognization")
                    return
                }
                
                
                if !myRecognization.isAvailable {
                   alertView(message: "After some time")
                }
                task = speechReconizer?.recognitionTask(with: request, resultHandler: {(response , error) in
                    guard let response = response else{
                        if error != nil{
                            print(error.debugDescription)
                        }else{
                            print(error.debugDescription)
                        }
                        return
                    }
                    let message = response.bestTranscription.formattedString
                    self.messageInputBar.inputTextView.text = message
                })
            }
            func cancelSpeech(){
                task.finish()
                task.cancel()
                task = nil
                
                
                request.endAudio()
                audioEngine.stop()
                audioEngine.inputNode.removeTap(onBus: 0)
            }
            
            func alertView(message:String){
                let alert = UIAlertController(title: "Alert", message: message, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default))
                self.present(alert, animated: true)
            }

    
    
}


extension ChatPageViewController{
   
}


//MARK: - FILLING DATA ON EDIT MODE

extension ChatPageViewController{
    func fill(conversation : DatabaseModel.ConversationModel){
        messages = []
        for prevessage in conversation.messages{
            let senderType : SenderType = prevessage.sender as ChatSender == .ai ? senderAI : selfSender
            var message = Message(sender: senderType, messageId: "1", sentDate: prevessage.sentDate, kind: .text(prevessage.content))
            messages.append(message)
        }
        DispatchQueue.main.async {
            self.messagesCollectionView.reloadData()
            
        }
    }
}






//MARK: - MESSAGE KIT FUNCTIONS

extension ChatPageViewController :  MessagesDataSource,MessagesDisplayDelegate,MessagesLayoutDelegate{
    func currentSender() -> SenderType {
        return selfSender
    }
    
    func messageForItem(at indexPath: IndexPath, in messagesCollectionView: MessagesCollectionView) -> MessageType {
        return messages[indexPath.section]
    }
    
    func numberOfSections(in messagesCollectionView: MessagesCollectionView) -> Int {
        return messages.count
    }
    
    
}

//MARK: - DATABASE AND CHAT STORAGE
extension ChatPageViewController{
    func storeChatInDatabase(){
        var messagesmodel : [DatabaseModel.MessageModel] = []
        for i in messages{
            var content : String = ""
            switch i.kind{
            case .text(let text):
                content = text
            default:
                break
            }
            let date = i.sentDate
            let senderId : ChatSender = i.sender.senderId == selfSender.senderId ? .user : .ai
            
            var message = DatabaseModel.MessageModel(content: content, sentDate: date, sender: senderId)
            messagesmodel.append(message)
        }
        var id :String = ""
        switch accessmode{
            
        case .start:
            id = UUID().uuidString
            
        case .edit(_):
            id = convoId!
        }
        conversation = DatabaseModel.ConversationModel(conversationId: id, messages: messagesmodel)
        DatabaseManager.shared.storeConverstaion(conversation: conversation) { result in
            if result{
                print("saved")
            }
            else{
                print("error")
            }
        }
    }
}


