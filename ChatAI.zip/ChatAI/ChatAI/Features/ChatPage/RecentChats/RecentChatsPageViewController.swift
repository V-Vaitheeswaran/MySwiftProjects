//
//  ViewController.swift
//  ChatAI
//
//  Created by Vaitheeswaran V on 02/02/23.
//

import UIKit

class RecentChatsPageViewController: UIViewController {

    
    @IBOutlet weak var tableView: UITableView!
        
    @IBOutlet weak var askVictorButton: UIButton!
    
    var conversations : [DatabaseModel.ConversationModel] = []
    var noContentLabel = UILabel()
    
    private var recentChatsTableData = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        buttonCreator()
        uiConstraints()
        getData()
        

      
    }
    
    @IBAction func addChatClicked(_ sender: Any) {
        let st = UIStoryboard(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "ChatPageViewController") as! ChatPageViewController
        vc.accessmode = .start

        self.navigationController?.pushViewController(vc, animated: true)
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getData()
        
    }
    
   

}

extension RecentChatsPageViewController {
    func uiConstraints(){
        view.addSubview(noContentLabel)
        noContentLabel.translatesAutoresizingMaskIntoConstraints = false
        noContentLabel.centerXAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerXAnchor).isActive = true
        noContentLabel.centerYAnchor.constraint(equalTo: view.safeAreaLayoutGuide.centerYAnchor).isActive = true
        noContentLabel.numberOfLines = 0
        noContentLabel.textAlignment = .center
        noContentLabel.text = "No recent chats to show.\nClick ' + ' to create new one "

    }
}


extension RecentChatsPageViewController:UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let convo = conversations[indexPath.row]
        let st = UIStoryboard(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "ChatPageViewController") as! ChatPageViewController
        vc.accessmode = .edit(convo)
        self.navigationController?.pushViewController(vc, animated: true)
    }
}

extension RecentChatsPageViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return conversations.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! RecentChatCell
        cell.questionLabel.text = conversations[indexPath.row].messages[1].content
        let timegap = timeGapReporter(date: conversations[indexPath.row].messages.last!.sentDate)
        cell.timeLabel.text = timegap
        cell.textLabel?.numberOfLines = 0
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 80
    }
    
}


extension RecentChatsPageViewController{
    func getData(){
        DatabaseManager.shared.fetchConversations { conversations in
            self.conversations = conversations
            DispatchQueue.main.async {
                if conversations.count == 0{
                    self.noContentLabel.isHidden = false
                    self.tableView.isHidden = true
                }
                else{
                    self.noContentLabel.isHidden = true
                    self.tableView.isHidden = false
                }
                self.tableView.reloadData()
            }
        }
    }
}


extension RecentChatsPageViewController{
    func buttonCreator(){
        
        askVictorButton.backgroundColor = UIColor.clear

        let aPath = UIBezierPath()

        aPath.move(to: CGPoint(x: 90.0, y: 35.0))

        aPath.addLine(to: CGPoint(x: 140.0, y: 30.0))

        aPath.addLine(to: CGPoint(x: 140.0, y: 70))

        aPath.close()
        
        

        let layer = CAShapeLayer()
        layer.fillColor = UIColor.link.cgColor
//        layer.strokeColor = UIColor.link.cgColor
        layer.path = aPath.cgPath

        askVictorButton.layer.addSublayer(layer)

    }
    
    func timeGapReporter(date:Date) -> String{
        let presentDate = Date.now
        var timeGap = ""
        let timeInterval : Int = Int(presentDate.timeIntervalSince(date))
        if timeInterval < 60{
            timeGap = "\(Int(timeInterval)) sec ago"
        }
        else if timeInterval < 3600 {
            timeGap = "\(Int(timeInterval / 60)) min ago"
        }
        else if timeInterval < 84600 {
            timeGap = "\(Int(timeInterval / 3600)) hours ago"
        }
        else if timeInterval < 604800 {
            timeGap = "\(Int(timeInterval / 84600)) days ago"
        }
        else if timeInterval < 2628288  {
            timeGap = "\(Int(timeInterval / 604800)) weeks ago"
        }
        else{
            timeGap = "\(Int(timeInterval / 604800)) months ago"
        }
        
        return timeGap
    }
}
