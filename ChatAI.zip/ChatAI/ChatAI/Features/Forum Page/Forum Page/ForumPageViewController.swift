//
//  ForumPageViewController.swift
//  ChatAI
//
//  Created by Vaitheeswaran V on 15/05/23.
//

import UIKit

class ForumPageViewController: UIViewController {
    
    @IBOutlet weak var segmentControl: UISegmentedControl!
        
    @IBOutlet weak var questionsTableView: UITableView!
    
    @IBOutlet weak var addQuestionButton: UIBarButtonItem!
    
    var questionsData : [DatabaseModel.ForumQuestionModel] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        segmentControl.selectedSegmentIndex = 0
        segmentControl.addTarget(self, action: #selector(segmentedControlValueChanged(_:)), for: .valueChanged)

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        getAndUpdateAllUserData()
    }
    
    @IBAction func createQuestionClicked(_ sender: Any) {
        let st = UIStoryboard(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "QuestionPageViewController") as! QuestionPageViewController
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
    func getAndUpdateAllUserData(){
        DatabaseManager.shared.fetchAllForumQuestions { data, error in
            if let data = data, error == nil{
                self.questionsData = data
                
            }
            else{
                print(error?.localizedDescription)
            }
            DispatchQueue.main.async {
                self.questionsTableView.reloadData()
            }
        }
    }
    
    func getAndUpdateUserData(){
        DatabaseManager.shared.fetchUserForumQuestions { data, error in
            if let data = data, error == nil{
                self.questionsData = data
                            }
            else{
                print(error?.localizedDescription)
            }
            
            DispatchQueue.main.async {
                self.questionsTableView.reloadData()
            }

        }
    }
    
}


extension ForumPageViewController : UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        tableView.deselectRow(at: indexPath, animated: false)
        let st = UIStoryboard(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "AnswersPageViewController") as! AnswersPageViewController
        vc.question = questionsData[indexPath.row]
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}

extension ForumPageViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return questionsData.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! ForumTableViewCell
        let data = questionsData[indexPath.row]
        cell.titleLabel.text = data.question.title
        cell.descriptionLabel.text = "asked by \(data.question.askedBy), \(timeGapReporter(date: data.question.date))"
        return cell
        
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 90
    }
    
    
}


extension ForumPageViewController{
    @objc private func segmentedControlValueChanged(_ sender: UISegmentedControl) {
        self.questionsData = []
        switch sender.selectedSegmentIndex{
        case 0:
            getAndUpdateAllUserData()
        case 1:
            print("second")
            getAndUpdateUserData()
        default:
            break
        }
    }
    
    func timeGapReporter(date:Date) -> String{
        let presentDate = Date.now
        var timeGap = ""
        let timeInterval : Int = Int(presentDate.timeIntervalSince(date))
        if timeInterval < 60{
            timeGap = "\(Int(timeInterval)) sec ago"
        }
        else if timeInterval < 3600 {
            timeGap = "\(Int(timeInterval / 60)) min ago"
        }
        else if timeInterval < 84600 {
            timeGap = "\(Int(timeInterval / 3600)) hours ago"
        }
        else if timeInterval < 604800 {
            timeGap = "\(Int(timeInterval / 84600)) days ago"
        }
        else if timeInterval < 2628288  {
            timeGap = "\(Int(timeInterval / 604800)) weeks ago"
        }
        else{
            timeGap = "\(Int(timeInterval / 604800)) months ago"
        }
        
        return timeGap
    }
}
