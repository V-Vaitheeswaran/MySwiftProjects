//
//  QuestionPageViewController.swift
//  ChatAI
//
//  Created by Vaitheeswaran V on 15/05/23.
//

import UIKit

class QuestionPageViewController: UIViewController {
    
    
    @IBOutlet weak var questionTitle: UITextField!
    
    @IBOutlet weak var detailedTextView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        extraUI()
    }
    
    
    @IBAction func saveButtonClicked(_ sender: Any) {
        saveTheQuestion()
    }
    
    
    func extraUI(){
        detailedTextView.layer.borderWidth = 1
        detailedTextView.layer.borderColor = UIColor.lightGray.cgColor
        detailedTextView.text = "Enter Your Problem In Detailed Version..."
        detailedTextView.textColor = .lightGray
    }
    
    func saveTheQuestion(){
        let id = UUID().uuidString
        let title = questionTitle.text!
        let description = detailedTextView.text!
        let date = Date.now
        let askedBy = UserDefaults.standard.value(forKey: "name") as! String
        let user = UserDefaults.standard.value(forKey: "email") as! String
        let question = DatabaseModel.QuestionModel(id: id, title: title, description: description, date: date, askedBy: askedBy, user: user)
        let answers : [DatabaseModel.AnswerModel] = []
        let forumQuestion = DatabaseModel.ForumQuestionModel(question: question, answers: answers)
        DatabaseManager.shared.storeForumQuestion(question: forumQuestion) { success in
            if success{
                print("question posted successfully")
            }
        }
        navigationController?.popViewController(animated: true)

    }

}

extension QuestionPageViewController : UITextViewDelegate{
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if detailedTextView.textColor == UIColor.lightGray {
            detailedTextView.text = nil
            detailedTextView.textColor = UIColor.label
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if detailedTextView.text.isEmpty {
            detailedTextView.text = "Enter Your Problem In Detailed Version..."
            detailedTextView.textColor = UIColor.lightGray
        }
    }
}
