//
//  AnswerPageViewController.swift
//  ChatAI
//
//  Created by Vaitheeswaran V on 18/05/23.
//

import UIKit

class AnswersPageViewController: UIViewController {
    
 
    @IBOutlet weak var questionTitle: UILabel!
    
    @IBOutlet weak var descriptionLabel: UILabel!
    
    @IBOutlet weak var answersTableView: UITableView!
    
    var question : DatabaseModel.ForumQuestionModel!
    var answers : [DatabaseModel.AnswerModel] = []
    var noAnswerView : UIView = {
        var view = UIView()
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    var noAnswerLabel : UILabel = {
        var label = UILabel()
        label.font = UIFont(name: "System", size: 20)
        label.text = "No Answers are available"
        label.translatesAutoresizingMaskIntoConstraints = false
        return label
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        noAnswerConstraints()
        

        noAnswerView.isHidden = true

    }
    @IBAction func addButtonClicked(_ sender: Any) {
        let st = UIStoryboard(name: "Main", bundle: nil)
        let vc = st.instantiateViewController(withIdentifier: "AddAnswerPageViewController") as! AddAnswerPageViewController
        vc.questionId = question.question.id
        vc.user = question.question.user
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        questionTitle.text = question.question.title
        descriptionLabel.text = question.question.description
        getAnswers { success in
            if success{
                if self.answers.count == 0{
                    self.answersTableView.isHidden = true
                    self.noAnswerView.isHidden = false
                }
                else{
                    self.answersTableView.isHidden = false
                    self.answersTableView.reloadData()
                    self.noAnswerView.isHidden = true
                }
            }
            else{
              print("error fetching data")
            }
        }
        
        
    }
    func getAnswers(completion:@escaping (Bool) -> Void) {
        DatabaseManager.shared.fetchAllAnswers(questionID: question.question.id) { model, error in
            if error == nil{
                self.answers = model
                completion(true)
                
            }
            else{
                completion(false)
                print(error?.localizedDescription)
            }
        }
    }
    func noAnswerConstraints(){
        view.addSubview(noAnswerView)
        noAnswerView.addSubview(noAnswerLabel)
        noAnswerView.topAnchor.constraint(equalTo: descriptionLabel.bottomAnchor, constant: 10).isActive = true
        noAnswerView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor).isActive = true
        noAnswerView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor).isActive = true
        noAnswerView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor).isActive = true
        
        noAnswerLabel.centerXAnchor.constraint(equalTo: noAnswerView.centerXAnchor).isActive = true
        noAnswerLabel.centerYAnchor.constraint(equalTo: noAnswerView.centerYAnchor).isActive = true
    }
}

extension AnswersPageViewController: UITableViewDelegate{
    
}

extension AnswersPageViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return answers.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "answerCell") as! RecentAnswersTableViewCell
        let data = answers[indexPath.row]
        cell.answerLabel.text = data.answer
        cell.answerbyLabel.text = "answered by \(data.writtenBy), \(timeGapReporter(date: data.date))"
//        cell.backgroundColor = .cyan
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    
}

extension AnswersPageViewController{
    func timeGapReporter(date:Date) -> String{
        let presentDate = Date.now
        var timeGap = ""
        let timeInterval : Int = Int(presentDate.timeIntervalSince(date))
        if timeInterval < 60{
            timeGap = "\(Int(timeInterval)) sec ago"
        }
        else if timeInterval < 3600 {
            timeGap = "\(Int(timeInterval / 60)) min ago"
        }
        else if timeInterval < 84600 {
            timeGap = "\(Int(timeInterval / 3600)) hours ago"
        }
        else if timeInterval < 604800 {
            timeGap = "\(Int(timeInterval / 84600)) days ago"
        }
        else if timeInterval < 2628288  {
            timeGap = "\(Int(timeInterval / 604800)) weeks ago"
        }
        else{
            timeGap = "\(Int(timeInterval / 604800)) months ago"
        }
        
        return timeGap
    }
}
