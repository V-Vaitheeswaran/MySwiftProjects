//
//  AddAnswerPageViewController.swift
//  ChatAI
//
//  Created by Vaitheeswaran V on 18/05/23.
//

import UIKit

class AddAnswerPageViewController: UIViewController {

    @IBOutlet weak var answerText: UITextView!
    
    var questionId : String = ""
    var user : String = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()
        extraUI()

    }
    
    @IBAction func saveButtonClicked(_ sender: Any) {
        print("saved")
        addAnswerToQuestion { success in
            if success{
                self.navigationController?.popViewController(animated: true)

            }
            else{
                print("Try again")
            }
        }

    }
    func extraUI(){
        answerText.layer.borderWidth = 1
        answerText.layer.borderColor = UIColor.lightGray.cgColor
        answerText.text = "Enter Your Answer..."
        answerText.textColor = .lightGray
    }
    
    


}

extension AddAnswerPageViewController{
    func addAnswerToQuestion(completion: @escaping (Bool) -> Void){
        let answer = answerText.text!
        let id = UUID().uuidString
        let date = Date.now
        let writtenBy = UserDefaults.standard.value(forKey: "name") as! String
        
        let answerModel = DatabaseModel.AnswerModel(id: id, answer: answer, date: date, writtenBy: writtenBy)
        let qid = questionId
        let user = user
        DatabaseManager.shared.addAnswerToQuestion(questionID: qid, email: user, answer: answerModel) { success, error in
            if error == nil{
                if success{
                    completion(true)
                   print("saved successfully")
                }
                else{
                    completion(false)

                    print("saving error")
                }
            }
            else{
                completion(false)

                print(error?.localizedDescription)
            }
            
        }
        
    }
}

extension AddAnswerPageViewController : UITextViewDelegate{
    
    func textViewDidBeginEditing(_ textView: UITextView) {
        if answerText.textColor == UIColor.lightGray {
            answerText.text = nil
            answerText.textColor = UIColor.label
        }
    }
    
    func textViewDidEndEditing(_ textView: UITextView) {
        if answerText.text.isEmpty {
            answerText.text = "Enter Your Answer..."
            answerText.textColor = UIColor.lightGray
        }
    }
}
