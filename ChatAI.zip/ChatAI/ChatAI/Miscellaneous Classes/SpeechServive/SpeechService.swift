//
//  SpeechService.swift
//  ChatAI
//
//  Created by Vaitheeswaran V on 15/05/23.
//

import Foundation
import AVFoundation

class SpeechService{
    
    static let shared = SpeechService()
    private let synthesizer = AVSpeechSynthesizer()
    
    func speak(text:String){
        let utterance = AVSpeechUtterance(string: text)
//        utterance.rate = 0.4
        synthesizer.speak(utterance)
    }
}
