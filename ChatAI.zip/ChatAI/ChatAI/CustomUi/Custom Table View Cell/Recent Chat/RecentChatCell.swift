//
//  RecentChatCell.swift
//  ChatAI
//
//  Created by Vaitheeswaran V on 12/05/23.
//

import UIKit

class RecentChatCell: UITableViewCell {
    
    
    
    @IBOutlet weak var recentChatImage: UIImageView!
    
    @IBOutlet weak var questionLabel: UILabel!
    
    @IBOutlet weak var timeLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
