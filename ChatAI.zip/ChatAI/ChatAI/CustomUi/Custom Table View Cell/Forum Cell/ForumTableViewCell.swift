//
//  ForumTableViewCell.swift
//  ChatAI
//
//  Created by Vaitheeswaran V on 15/05/23.
//

import UIKit

class ForumTableViewCell: UITableViewCell {

    @IBOutlet weak var titleLabel: UILabel!
    
    @IBOutlet weak var descriptionLabel: UILabel!
    
}
