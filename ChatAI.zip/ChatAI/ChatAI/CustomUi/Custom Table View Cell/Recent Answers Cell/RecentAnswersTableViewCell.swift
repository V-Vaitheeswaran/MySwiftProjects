//
//  RecentAnswersTableViewCell.swift
//  ChatAI
//
//  Created by Vaitheeswaran V on 18/05/23.
//

import UIKit

class RecentAnswersTableViewCell: UITableViewCell {

    @IBOutlet weak var answerLabel: UILabel!
    
    @IBOutlet weak var answerbyLabel: UILabel!
    
}
