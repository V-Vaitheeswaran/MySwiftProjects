//
//  APICaller.swift
//  ChatAI
//
//  Created by Vaitheeswaran V on 22/02/23.
//
import OpenAISwift
import Foundation

// api key : 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
class APICaller{
    static let shared = APICaller()
    
    @frozen enum Constants{
        static let key = "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"
    }
    private var client : OpenAISwift!
    private init(){
        
    }
    
    public func setup(){
        self.client = OpenAISwift(authToken: Constants.key)
    }
    
    func getResponse(input : String, completion : @escaping((Result<String,Error>)-> Void)){
        client.sendCompletion(with: input,model: .chat(.chatgpt)) { result in
            switch result {
            case .success(let model):
                let output = model.choices?.first?.text ?? ""
                print("API response: \(output)") // Add this line to print the API response
                completion(.success(output))
            case .failure(let error):
                print("API error: \(error.localizedDescription)") // Add this line to print any API errors
                completion(.failure(error))
            }
        }
        
    }
}
