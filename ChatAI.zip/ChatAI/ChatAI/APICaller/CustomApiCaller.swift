//
//  CustomApiCaller.swift
//  ChatAI
//
//  Created by Vaitheeswaran V on 11/05/23.
//

import Foundation
import OpenAIKit

class APIEngine{
    
    static let shared = APIEngine()
    
    let apiKey = "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"

    func getRequest(prompt : String, completion : @escaping((Result<String,Error>)-> Void)){
        let openAI = OpenAIKit(apiToken: apiKey)
        // Set up a question
        openAI.sendChatCompletion(newMessage: AIMessage(role: .user, content: prompt), previousMessages: [], model: .gptV3_5(.gptTurbo), maxTokens: 2048, n: 1, completion: { [weak self] result in
            
            switch result {
            case .success(let aiResult):
                // Handle result actions
                if let text = aiResult.choices.first?.message?.content {
                    completion(.success(text))
                }
            case .failure(let error):
                // Handle error actions
                completion(.failure(error))
            }
        })

    }








}





