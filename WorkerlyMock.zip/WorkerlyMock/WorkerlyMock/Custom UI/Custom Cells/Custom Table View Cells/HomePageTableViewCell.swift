//
//  HomePageTableViewCell.swift
//  WorkerlyMock
//
//  Created by Vaitheeswaran V on 08/04/23.
//

import UIKit

class HomePageTableViewCell: UITableViewCell {
    
    @IBOutlet weak var profilePic: UIImageView!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var subLabel: UILabel!
    
    
}
