//
//  ProfileViewController.swift
//  WorkerlyMock
//
//  Created by Vaitheeswaran V on 12/04/23.
//

import UIKit
import SSOKit

class ProfileViewController: UIViewController {

  
    @IBOutlet weak var profileTable: UITableView!
    
    @IBOutlet weak var profilePic: UIImageView!
    
    @IBOutlet weak var userName: UILabel!
    
    @IBOutlet weak var userEmail: UILabel!
    
    @IBOutlet weak var logOutButton: UIButton!
    
    var settingsArray = ["Settings","Rate Us","Feedback","Version"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        let user = ZSSOKit.getCurrentUser().profile
        userName.text = user?.displayName
        userEmail.text = user?.email
        if let imgData = user?.profileImageData{
            profilePic.image = UIImage(data: imgData)
            profilePic.layer.cornerRadius = profilePic.frame.width/2

        }
        else{
            profilePic.image = UIImage(systemName: "person.circle")
            profilePic.layer.cornerRadius = profilePic.frame.width/2

        }
    }
    
    
    @IBAction func logOutClicked(_ sender: Any) {
        print("log out")
       // let zuid = ZSSOKit.getCurrentUser().userZUID
        
        ZSSOKit.revokeAccessToken { error in
            if error == nil{
                oAuthToken = ""
                DispatchQueue.main.async {
                    let st = UIStoryboard(name: "WorkerlyMock", bundle: nil)
                    let vc = st.instantiateViewController(withIdentifier: "LoginPageViewController") as! LoginPageViewController
                    UIApplication.shared.windows.first?.rootViewController = vc
                    UIApplication.shared.windows.first?.makeKeyAndVisible()
                }
            }
            else{
                print(error?.localizedDescription)
            }
            
        }
        
       
    }

}

extension ProfileViewController : UITableViewDelegate{
    
}

extension ProfileViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return settingsArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell")!
        cell.textLabel?.text = settingsArray[indexPath.row]
        return cell
    }
    
    
}
