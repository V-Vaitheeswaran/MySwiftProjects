//
//  HomePageRouter.swift
//  WorkerlyMock
//
//  Created by Vaitheeswaran V on 17/04/23.
//

import Foundation
import UIKit

protocol HomePageWireFrameLogic{
   func sessionExpired()
}

class HomePageRouter : HomePageWireFrameLogic{
   
    weak var viewController : UIViewController!
    func sessionExpired(){
        DispatchQueue.main.async {
            let st = UIStoryboard(name: "WorkerlyMock", bundle: nil)
            let vc = st.instantiateViewController(withIdentifier: "LoginPageViewController") as! LoginPageViewController
            UIApplication.shared.windows.first?.rootViewController = vc
            UIApplication.shared.windows.first?.makeKeyAndVisible()
        }
        
    }

}
