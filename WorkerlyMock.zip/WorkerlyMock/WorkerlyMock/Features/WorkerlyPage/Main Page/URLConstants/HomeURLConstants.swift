//
//  URLConstants.swift
//  WorkerlyMock
//
//  Created by Vaitheeswaran V on 17/04/23.
//

import Foundation

//MARK: - HOME PAGE URL CONSTANTS AND HEADERS
let homeUrl = "https://workerly.localzoho.com/workerly/v2/report/whoisworking?type=allshifts&page=0&per_page=100"

let homeHeaders = ["Content-Type":"application/json",
                   "Authorization":"Zoho-oauthtoken \(oAuthToken)"]
