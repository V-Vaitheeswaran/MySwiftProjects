//
//  ViewController.swift
//  WorkerlyMock
//
//  Created by Vaitheeswaran V on 05/04/23.
//


//1002.e31e20316693c04f52510cf410a73d2f.fc9eb3684fac3f10c559d15217be9593

import UIKit
import SSOKit

protocol HomePageDisplayLogic : AnyObject{
    func updateData(data:[CurrentWorkingHandlerViewModel.TempDetails])
    func sessionExpired()
}

class HomePageViewController: UIViewController {
    
    @IBOutlet weak var currentWorkingTempsTable: UITableView!
    var interactor : HomePageBusinessLogic!
    var router : HomePageWireFrameLogic!
    var tempDetails : [CurrentWorkingHandlerViewModel.TempDetails] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setUp()
//        self.interactor.getData()

//        print(" auth token : \(OauthToken)")
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)

    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        gettingData()

    }
    
    func gettingData(){
        ZSSOKit.getOAuth2Token { accestoken, error in
            if let token = accestoken{
                oAuthToken = token
                self.interactor.getDataUsingNetworkHandler()
            }
            
            else{
                print("Authenication Failed!!!")
            }
            

        }
    }
    
    func setUp(){
        let interactor = HomePageInteractor()
        let presenter = HomePagePresenter()
        let viewcontroller = self
        let router = HomePageRouter()
        interactor.presenter = presenter
        presenter.viewController = viewcontroller
        viewcontroller.interactor = interactor
        viewcontroller.router = router
        router.viewController = viewcontroller
        
    }
}


extension HomePageViewController : HomePageDisplayLogic{
    func updateData(data:[CurrentWorkingHandlerViewModel.TempDetails]){
        tempDetails = data
        DispatchQueue.main.async {
            self.currentWorkingTempsTable.reloadData()
        }
    }
    
    func sessionExpired(){
//        ZSSOKit().updateTokenAfterExpiry {
//            print(oAuthToken)
//            self.interactor.getData()
//        }
        
    }
    
}

extension HomePageViewController : UITableViewDelegate{
    
}

extension HomePageViewController : UITableViewDataSource{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return tempDetails.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell") as! HomePageTableViewCell
        let cellData = tempDetails[indexPath.row]
        cell.profilePic.image = UIImage(systemName: "person.circle")
        cell.profilePic.layer.cornerRadius = cell.profilePic.frame.width/2
        cell.nameLabel.text = cellData.tempName
        if cellData.relationAllDay{
            cell.subLabel.text = "All Day ( \(cellData.relationPlannedHours))"
        }
        else if(cellData.isNightSchedule){
            cell.subLabel.text = "Night Shift \n \((cellData.scheduleStartTime)!) -- \((cellData.scheduleEndTime)!)"
        }
        else{
            cell.subLabel.text = "\((cellData.scheduleStartTime)!) -- \((cellData.scheduleEndTime)!)"
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100
    }
    
    
    
    
    
}
