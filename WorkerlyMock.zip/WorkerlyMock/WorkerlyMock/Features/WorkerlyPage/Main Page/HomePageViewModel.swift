//
//  HomePageViewModel.swift
//  WorkerlyMock
//
//  Created by Vaitheeswaran V on 17/04/23.
//

import Foundation
struct HomePageViewModel{
    
    struct DataModel{
        let data : Data
    }
    
    //MARK: -  Home page data model
    
    struct HomePageModel: Codable {
        let data: [TempDetails]
        let info: Info
    }

    // MARK: - Datum
    struct TempDetails: Codable {
        let relationAllDay: Bool
        let jobID, onTheWay, tempName: String
        let isNightSchedule: Bool
        let relationDate, relationPlannedHours, id, tempID: String
        let scheduleID: String
        let relationEndTime, scheduleStartTime, nextRelationDate, relationStartTime: String?
        let scheduleEndTime: String?

        enum CodingKeys: String, CodingKey {
            case relationAllDay
            case jobID = "jobId"
            case onTheWay, tempName, isNightSchedule, relationDate, relationPlannedHours, id
            case tempID = "tempId"
            case scheduleID = "scheduleId"
            case relationEndTime, scheduleStartTime, nextRelationDate, relationStartTime, scheduleEndTime
        }
    }

    // MARK: - Info
    struct Info: Codable {
    }

}

