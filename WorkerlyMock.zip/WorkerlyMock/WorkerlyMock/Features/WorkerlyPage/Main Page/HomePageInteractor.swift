//
//  HomePageInteractor.swift
//  WorkerlyMock
//
//  Created by Vaitheeswaran V on 13/04/23.
//



import Foundation
import CoreData
import UIKit
import SSOKit


protocol HomePageBusinessLogic{
    func getData()
    func getDataUsingNetworkHandler()
    
}


class HomePageInteractor : HomePageBusinessLogic{
  
    var presenter : HomePagePresenterLogic!
    
    func getData(){
        let url = URL(string: homeUrl)!
        var request = URLRequest(url: url)
        request.httpMethod = "GET"
        for i in homeHeaders.keys{
            request.setValue(homeHeaders[i], forHTTPHeaderField: i)
        }
        
        let task = URLSession.shared.dataTask(with: request) { (data, response, error) in
            
            // Check if Error took place
            if let error = error {
                print("Error took place \(error)")
                return
            }
//             Read HTTP Response Status code
            if let response = response as? HTTPURLResponse {
                print("Response HTTP Status code: \(response.statusCode)")
                
            }
            
            // Convert HTTP Response Data to a simple String
            if let data = data {
                print(data)
                let dataModel = HomePageViewModel.DataModel(data: data)
                self.presenter.formatData(data: dataModel)
            }
            
          
        }
        task.resume()
    }
    
    func getDataUsingNetworkHandler() {
        CurrentWorkingHandler().getDataOfCurrentWorkingTemps { object, error in
            if error == nil{
                if let model = object?.data {
                    
                    self.presenter.passData(data: model)
                }
                else{
                    print("No data Error !!!")
                }
            }
            else{
                print(error?.localizedDescription)
            }
        }
    }
    
    
}
