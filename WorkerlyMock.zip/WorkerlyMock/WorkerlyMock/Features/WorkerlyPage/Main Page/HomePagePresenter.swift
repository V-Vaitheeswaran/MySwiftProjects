//
//  HomePagePresenter.swift
//  WorkerlyMock
//
//  Created by Vaitheeswaran V on 13/04/23.
//

import Foundation
import CoreData


protocol HomePagePresenterLogic{
    func formatData(data: HomePageViewModel.DataModel)
    func authfailed()
    func passData(data:[CurrentWorkingHandlerViewModel.TempDetails])
}


class HomePagePresenter : HomePagePresenterLogic{
    
    
    
    weak var viewController : HomePageDisplayLogic!
    
    func formatData(data: HomePageViewModel.DataModel){
        let result = try? JSONDecoder().decode(HomePageViewModel.HomePageModel.self,from: data.data)
        
        print(result?.data )
        guard let result = result else{
            return
        }
//        viewController.updateData(data: result.data)
    }
    func authfailed(){
        viewController.sessionExpired()
    }

    func passData(data:[CurrentWorkingHandlerViewModel.TempDetails]) {
        viewController.updateData(data: data)
    }
}


