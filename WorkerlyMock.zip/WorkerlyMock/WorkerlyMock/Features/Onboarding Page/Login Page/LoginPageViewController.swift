//
//  LoginPageViewController.swift
//  WorkerlyMock
//
//  Created by Vaitheeswaran V on 06/04/23.
//

import UIKit
import SSOKit

class LoginPageViewController: UIViewController {
    
    @IBOutlet weak var loginButton: UIButton!
        
    var sessionexpired = false
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
       
    }
    
    @IBAction func loginButtonClicked(_ sender: Any) {
        //ZSSOKit().initInWithClientId(window: mainWindow)
        ZSSOKit().presentLoginPage()
    }
    

    
    @IBAction func clearToken(_ sender: Any) {
        ZSSOKit.revokeAccessToken { error in
            
        }
    }
    


}
