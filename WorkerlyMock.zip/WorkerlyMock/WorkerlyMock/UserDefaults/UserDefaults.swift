//
//  UserDefaults.swift
//  WorkerlyMock
//
//  Created by Vaitheeswaran V on 20/04/23.
//

import Foundation

var sceneDelegateWindow = SceneDelegate()
var oAuthToken = ""
