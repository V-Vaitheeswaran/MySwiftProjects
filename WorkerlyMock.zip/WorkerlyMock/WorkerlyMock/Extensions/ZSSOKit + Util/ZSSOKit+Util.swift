//
//  ZSSOKit+Util.swift
//  WorkerlyMock
//
//  Created by Vaitheeswaran V on 06/04/23.
//

import Foundation
import SSOKit



struct ClientConstants{
    var Scopes = ["ZohoWorkerly.modules.ALL","ZohoWorkerly.setup.ALL","ZohoWorkerly.settings.unavailability.ALL"]
    var URLSchema =  "workerlyagent"
    var BuildType = SSOBuildType.Local_SSO_Mdm
    var ClientId = "1002.4DYLRPLL04HMLX1ZGF1H487QBP0JYA"

}

extension ZSSOKit{
    
    func initInWithClientId(){
        let constants = ClientConstants()
        ZSSOKit.initWithClientID(constants.ClientId, scope:constants.Scopes, urlScheme: constants.URLSchema, mainWindow: sceneDelegateWindow.window, buildType: constants.BuildType)
    }
    
    func presentLoginPage(){
        initInWithClientId()
        ZSSOKit.presentInitialViewController { (accessToken, error) in
            if let err = error {
                print(err)
                //Handle login errors with proper alerts and redirection
            } else {
                UserDefaults.standard.set(accessToken, forKey: "authToken")
                print(accessToken)
                let st = UIStoryboard(name: "WorkerlyMock", bundle: nil)
                let vc = st.instantiateViewController(withIdentifier: "WorkerlyMainTab") as! UITabBarController
                UIApplication.shared.windows.first?.rootViewController = vc
                UIApplication.shared.windows.first?.makeKeyAndVisible()            }
        }
    }
    
    func updateTokenAfterExpiry(_ completion : @escaping () -> Void){
        ZSSOKit.getOAuth2Token { token, error in
            oAuthToken = token ?? ""
           // UserDefaultStorage.shared.oAuthToken = token!
            completion()
        }
        
    }
}
